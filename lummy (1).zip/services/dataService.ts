
import { Job, Message, CalendarEvent, AppNotification, UserRole, JobApplication, ApplicationStatus } from '../types';

// Storage Keys (Fallback)
const KEYS = {
  JOBS: 'lummy_jobs',
  MESSAGES: 'lummy_messages',
  EVENTS: 'lummy_events',
  NOTIFICATIONS: 'lummy_notifications',
  APPLICATIONS: 'lummy_applications',
};

// Seed Data
const SEED_JOBS: Job[] = [
  {
    id: '1',
    title: 'Senior Frontend Engineer',
    company: 'Nebula Stream',
    location: 'Remote',
    salary: '$140k - $180k',
    matchScore: 92,
    posted: '2 days ago',
    requirements: ['React', 'TypeScript', 'WebGL', 'Tailwind'],
    description: "We are looking for a visionary frontend engineer to lead our core product interface. You will be responsible for architecting the next generation of our streaming platform.",
    applyLink: 'https://example.com/apply/nebula',
    saved: false
  },
  {
    id: '2',
    title: 'Full Stack Developer (AI Focus)',
    company: 'Cognitive Layer',
    location: 'San Francisco, CA',
    salary: '$160k - $210k',
    matchScore: 88,
    posted: '4 hours ago',
    requirements: ['Python', 'React', 'TensorFlow', 'PostgreSQL'],
    description: "Join the team building the brain of the future. You will integrate large language models into intuitive user interfaces.",
    applyLink: 'https://example.com/apply/cognitive',
    saved: false
  },
  {
    id: '3',
    title: 'UI/UX Technologist',
    company: 'Aether Design',
    location: 'New York, NY',
    salary: '$130k - $160k',
    matchScore: 75,
    posted: '1 week ago',
    requirements: ['Figma', 'React', 'CSS Modules', 'Motion'],
    description: "Bridge the gap between design and engineering. You must have an eye for pixel perfection and a heart for performance.",
    applyLink: 'https://example.com/apply/aether',
    saved: true
  }
];

const SEED_EVENTS: CalendarEvent[] = [
  { id: '1', title: 'Technical Interview', candidate: 'Jane Doe', date: '2023-10-24', time: '10:00 AM', type: 'Google Meet', link: 'meet.google.com/abc-defg-hij' },
  { id: '2', title: 'Culture Fit Chat', candidate: 'John Smith', date: '2023-10-24', time: '02:00 PM', type: 'Google Meet', link: 'meet.google.com/xyz-uvw-rst' },
  { id: '3', title: 'Final Round', candidate: 'Sarah Connor', date: '2023-10-25', time: '11:00 AM', type: 'In-Person' },
];

const SEED_MESSAGES: Message[] = [
  { id: '1', senderId: 'recruiter', senderName: 'Nebula Stream Recruiter', role: 'employer', content: "Hi Alex! We reviewed your profile and think you'd be a great fit for the Senior Frontend role.", timestamp: 1678880000000 },
  { id: '2', senderId: 'me', senderName: 'Alex Chen', role: 'user', content: "Hi! Thank you for reaching out. I'm definitely interested. I love what Nebula Stream is doing with WebGL.", timestamp: 1678880100000 },
  { id: '3', senderId: 'recruiter', senderName: 'Nebula Stream Recruiter', role: 'employer', content: "Glad to hear that. Are you available for a quick sync this week?", timestamp: 1678880200000 },
  { id: '4', senderId: 'recruiter', senderName: 'Nebula Stream Recruiter', role: 'employer', content: "Would 2 PM EST work for the interview?", timestamp: 1678880250000 },
];

const SEED_NOTIFICATIONS: AppNotification[] = [
  {
    id: '1',
    title: 'Interview Confirmed',
    message: 'Google Calendar invite sent to alex@lummy.ai for "Technical Round with Nebula Stream".',
    type: 'email',
    timestamp: Date.now() - 3600000,
    read: false,
    targetRole: 'CANDIDATE'
  },
  {
    id: '2',
    title: 'New Applicant',
    message: 'Jane Doe just applied for Senior Frontend Engineer.',
    type: 'system',
    timestamp: Date.now() - 7200000,
    read: false,
    targetRole: 'EMPLOYER'
  },
  {
    id: '3',
    title: 'Profile Viewed',
    message: 'A recruiter from Cognitive Layer viewed your profile.',
    type: 'system',
    timestamp: Date.now() - 86400000,
    read: true,
    targetRole: 'CANDIDATE'
  }
];

const SEED_APPLICATIONS: JobApplication[] = [
  {
    id: '101',
    jobId: '99',
    title: 'Frontend Architect',
    company: 'Stellar Systems',
    location: 'Remote',
    salary: '$180k',
    dateApplied: Date.now() - 604800000, // 1 week ago
    status: 'INTERVIEW',
    platform: 'LinkedIn'
  },
  {
    id: '102',
    jobId: '98',
    title: 'React Native Lead',
    company: 'AppWorks',
    location: 'Austin, TX',
    salary: '$165k',
    dateApplied: Date.now() - 259200000, // 3 days ago
    status: 'SCREENING',
    platform: 'Lummy Auto-Pilot'
  },
  {
    id: '103',
    jobId: '97',
    title: 'Design Systems Engineer',
    company: 'PixelPerfect',
    location: 'Remote',
    salary: '$150k',
    dateApplied: Date.now() - 1209600000, // 2 weeks ago
    status: 'REJECTED',
    platform: 'Manual'
  }
];

// ----------------------------------------------------------------------
// HELPER: Local Storage Fallbacks (for when Firebase is not configured)
// ----------------------------------------------------------------------
const local = {
  get: (key: string, seed: any) => {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : seed;
  },
  set: (key: string, data: any) => localStorage.setItem(key, JSON.stringify(data)),
  add: (key: string, item: any, seed: any) => {
    const current = local.get(key, seed);
    const updated = [item, ...current];
    local.set(key, updated);
    return updated;
  }
};

// Helper to simulate network delay for local operations
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// ----------------------------------------------------------------------
// MAIN SERVICE
// ----------------------------------------------------------------------
export const dataService = {
  /**
   * Initialize Local DB with seed data if empty
   */
  init: () => {
    if (!localStorage.getItem(KEYS.JOBS)) localStorage.setItem(KEYS.JOBS, JSON.stringify(SEED_JOBS));
    if (!localStorage.getItem(KEYS.EVENTS)) localStorage.setItem(KEYS.EVENTS, JSON.stringify(SEED_EVENTS));
    if (!localStorage.getItem(KEYS.MESSAGES)) localStorage.setItem(KEYS.MESSAGES, JSON.stringify(SEED_MESSAGES));
    if (!localStorage.getItem(KEYS.NOTIFICATIONS)) localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(SEED_NOTIFICATIONS));
    if (!localStorage.getItem(KEYS.APPLICATIONS)) localStorage.setItem(KEYS.APPLICATIONS, JSON.stringify(SEED_APPLICATIONS));
  },

  /**
   * JOBS
   */
  getJobs: async (): Promise<Job[]> => {
    await delay(300);
    return local.get(KEYS.JOBS, SEED_JOBS);
  },

  createJob: async (job: Omit<Job, 'id' | 'posted' | 'matchScore'>): Promise<Job> => {
    const newJobBase = {
      ...job,
      posted: new Date().toISOString(), // Use ISO for data consistency
      matchScore: Math.floor(Math.random() * 30) + 70,
      saved: false
    };

    await delay(500);
    const newJob = { ...newJobBase, id: Date.now().toString(), posted: 'Just now' } as Job;
    local.add(KEYS.JOBS, newJob, SEED_JOBS);

    // Trigger Local Notification
    dataService.createNotification({
      title: 'New Job Match',
      message: `A new role "${newJob.title}" at ${newJob.company} matches your profile 92%.`,
      type: 'email',
      targetRole: 'CANDIDATE'
    });

    return newJob;
  },

  toggleJobSave: async (jobId: string): Promise<boolean> => {
    await delay(100);
    const jobs = local.get(KEYS.JOBS, SEED_JOBS);
    let newStatus = false;
    const updatedJobs = jobs.map((job: Job) => {
        if (job.id === jobId) {
            newStatus = !job.saved;
            return { ...job, saved: newStatus };
        }
        return job;
    });
    local.set(KEYS.JOBS, updatedJobs);
    return newStatus;
  },

  /**
   * APPLICATIONS (HISTORY)
   */
  getApplications: async (): Promise<JobApplication[]> => {
    await delay(200);
    return local.get(KEYS.APPLICATIONS, SEED_APPLICATIONS);
  },

  trackApplication: async (job: Job, platform: JobApplication['platform'] = 'Manual'): Promise<JobApplication> => {
    const app: JobApplication = {
      id: Date.now().toString(),
      jobId: job.id,
      title: job.title,
      company: job.company,
      location: job.location,
      salary: job.salary,
      dateApplied: Date.now(),
      status: 'APPLIED',
      platform
    };
    await delay(200);
    local.add(KEYS.APPLICATIONS, app, SEED_APPLICATIONS);
    return app;
  },

  updateApplicationStatus: async (appId: string, status: ApplicationStatus) => {
    await delay(200);
    const apps = local.get(KEYS.APPLICATIONS, SEED_APPLICATIONS);
    const updated = apps.map((a: JobApplication) => a.id === appId ? { ...a, status } : a);
    local.set(KEYS.APPLICATIONS, updated);
  },

  /**
   * EVENTS
   */
  getEvents: async (): Promise<CalendarEvent[]> => {
    await delay(200);
    return local.get(KEYS.EVENTS, SEED_EVENTS);
  },

  /**
   * MESSAGES
   */
  getMessages: async (): Promise<Message[]> => {
    await delay(100);
    return local.get(KEYS.MESSAGES, SEED_MESSAGES);
  },

  sendMessage: async (content: string, role: 'user' | 'employer', senderName: string): Promise<Message> => {
    const newMessageBase = {
      senderId: role === 'user' ? 'me' : 'employer',
      senderName,
      role,
      content,
      timestamp: Date.now()
    };

    await delay(200);
    const newMessage = { id: Date.now().toString(), ...newMessageBase } as Message;
    local.add(KEYS.MESSAGES, newMessage, SEED_MESSAGES);
    return newMessage;
  },

  /**
   * NOTIFICATIONS
   */
  getNotifications: async (role: UserRole): Promise<AppNotification[]> => {
    const all = local.get(KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
    return all.filter((n: AppNotification) => n.targetRole === role || n.targetRole === 'BOTH')
              .sort((a: AppNotification, b: AppNotification) => b.timestamp - a.timestamp);
  },

  createNotification: async (notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
    const newNotifBase = {
      ...notif,
      timestamp: Date.now(),
      read: false
    };

    const newNotif = { id: Date.now().toString(), ...newNotifBase } as AppNotification;
    local.add(KEYS.NOTIFICATIONS, newNotif, SEED_NOTIFICATIONS);
    return newNotif;
  },

  markNotificationRead: async (id: string) => {
    const all = local.get(KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
    const updated = all.map((n: AppNotification) => n.id === id ? { ...n, read: true } : n);
    local.set(KEYS.NOTIFICATIONS, updated);
  },
  
  markAllNotificationsRead: async (role: UserRole) => {
    const all = local.get(KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
    const updated = all.map((n: AppNotification) => 
       (n.targetRole === role || n.targetRole === 'BOTH') ? { ...n, read: true } : n
    );
    local.set(KEYS.NOTIFICATIONS, updated);
  }
};

// Initialize fallback immediately
dataService.init();
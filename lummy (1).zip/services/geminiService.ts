import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { Message, NetworkProfile } from "../types";

// Initialize the API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_FAST = 'gemini-2.5-flash';
const MODEL_SMART = 'gemini-3-pro-preview';

export interface CandidateProfile {
  summary: string;
  technical: string;
  cultural: string;
  experience: string;
  softSkills: string[];
}

export interface GrowthMilestone {
  id: string;
  title: string;
  description: string;
  duration: string;
  skills: string[];
  resources: string[];
  status: 'completed' | 'in-progress' | 'locked';
}

export interface GrowthPlan {
  targetRole: string;
  milestones: GrowthMilestone[];
  habits: string[];
}

export interface InterviewFeedback {
  score: number;
  summary: string;
  strengths: string[];
  improvements: string[];
}

/**
 * Tailors a resume based on the user's current resume and a target job description.
 */
export const tailorResume = async (
  currentResume: string,
  jobDescription: string
): Promise<{ tailoredResume: string; reasoning: string }> => {
  try {
    const prompt = `
      You are Lummy, an expert career architect. 
      
      Task: transform the provided Candidate Resume to perfectly align with the Target Job Description.
      
      Candidate Resume:
      ${currentResume}

      Target Job Description:
      ${jobDescription}

      Output Requirements:
      Return a JSON object with two fields:
      1. "tailoredResume": The rewritten resume content (in Markdown format). Enhance bullet points with metrics where possible, reorder skills to match the job, and adopt keywords from the JD. Do not invent false experiences, but reframe existing ones.
      2. "reasoning": A brief paragraph explaining the key strategic changes you made and why.

      Ensure the tone is professional, impactful, and authentic.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_SMART,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text);
  } catch (error) {
    console.error("Error tailoring resume:", error);
    throw error;
  }
};

/**
 * Creates a chat session for interview simulation.
 */
export const createInterviewSession = (jobTitle: string, company: string): Chat => {
  return ai.chats.create({
    model: MODEL_FAST,
    config: {
      systemInstruction: `You are a seasoned Hiring Manager at ${company}, interviewing a candidate for the position of ${jobTitle}. 
      Your goal is to conduct a realistic, slightly challenging, but professional interview.
      Start by asking the candidate to introduce themselves.
      Ask one question at a time.
      After the candidate answers, briefly acknowledge their answer (critique if necessary, but keep it conversational) and move to the next relevant question.
      Cover technical skills, behavioral situations, and cultural fit.
      Keep your responses concise (under 100 words) to maintain a conversational flow.`
    }
  });
};

/**
 * Sends a message to the chat session.
 */
export const sendInterviewMessage = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "I'm sorry, I didn't catch that. Could you please repeat?";
  } catch (error) {
    console.error("Error in interview chat:", error);
    return "Let's pause for a moment. Please continue when you're ready.";
  }
};

/**
 * Analyzes the interview transcript and provides detailed feedback.
 */
export const generateInterviewFeedback = async (messages: Message[]): Promise<InterviewFeedback> => {
  try {
    // Convert messages to a readable transcript
    const transcript = messages
      .map(m => `${m.role === 'user' ? 'Candidate' : 'Interviewer'}: ${m.content}`)
      .join('\n\n');

    const prompt = `
      Analyze the following interview transcript between a Hiring Manager and a Candidate.
      
      Transcript:
      ${transcript}

      Provide a structured evaluation in JSON format with the following fields:
      1. "score": An integer from 0-100 representing the candidate's overall performance.
      2. "summary": A 2-sentence executive summary of how the interview went.
      3. "strengths": An array of 3 specific things the candidate did well.
      4. "improvements": An array of 3 actionable tips for improvement.

      Be constructive, critical but encouraging.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_SMART,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Feedback generation error", error);
    return {
      score: 0,
      summary: "Could not generate feedback due to an error.",
      strengths: [],
      improvements: []
    };
  }
};

/**
 * Analyzes a job description to provide a quick "Lummy Insight".
 */
export const analyzeJobMatch = async (resume: string, jobDescription: string): Promise<string> => {
   try {
    const response = await ai.models.generateContent({
      model: MODEL_FAST,
      contents: `
        Compare this resume summary: "${resume.slice(0, 500)}..." 
        with this job description: "${jobDescription.slice(0, 500)}...".
        
        Provide a 2-sentence "Lummy Insight" on the compatibility. Be encouraging but realistic.
      `,
    });
    return response.text || "Analysis unavailable.";
  } catch (error) {
    return "Unable to generate insight at this moment.";
  }
}

/**
 * Generates a concise Ideal Candidate Profile based on the job description.
 */
export const generateCandidateProfile = async (jobDescription: string, requirements: string[] = []): Promise<CandidateProfile> => {
  try {
    const prompt = `
      Analyze this job description and key requirements to construct a detailed "Ideal Candidate Profile".
      Provide a JSON object with the following keys:
      1. "summary": A concise 2-sentence overview of the ideal candidate persona.
      2. "technical": A summary of the core technical skills and technologies required (approx 30 words).
      3. "cultural": A detailed insight into the company culture, values, and cultural fit (approx 40-50 words).
      4. "experience": The seniority, background, and specific experience expected (approx 30 words).
      5. "softSkills": An array of 4-6 specific soft skills or behavioral traits mentioned or implied.

      Job Description:
      ${jobDescription.slice(0, 2000)}

      Key Requirements:
      ${requirements.join(', ')}

      Return ONLY a JSON object.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_FAST,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    return JSON.parse(text);
  } catch (error) {
    console.error("Profile generation error", error);
    return {
      summary: "Analysis unavailable",
      technical: "Analysis unavailable",
      cultural: "Analysis unavailable",
      experience: "Analysis unavailable",
      softSkills: []
    };
  }
};

/**
 * Generates a job description for Employers.
 */
export const generateJobDescription = async (title: string, keywords: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_SMART,
      contents: `Write a compelling, modern, and inclusive job description for a "${title}". 
      Key requirements/keywords: ${keywords}.
      Structure it with: Role Overview, Key Responsibilities, and What You Bring.
      Keep it under 300 words. Format as Markdown.`,
    });
    return response.text || "Drafting...";
  } catch (error) {
    return "Error generating description.";
  }
}

/**
 * Simulates scouting talent from the web (Indeed/LinkedIn/Database).
 * Returns mock candidates based on the search query.
 */
export const scoutTalent = async (roleQuery: string): Promise<any[]> => {
  try {
    const prompt = `
      You are an AI recruiter. Generate 4 realistic, high-quality candidate profiles for the role of: "${roleQuery}".
      
      For each candidate, provide:
      - id: unique string
      - name: realistic full name
      - role: current job title
      - matchScore: integer between 70 and 99
      - skills: array of 3-4 top skills
      - experience: 1 sentence summary
      - source: Randomly pick 'LinkedIn', 'Indeed', or 'Database'
      - bio: A short 2-sentence professional summary.

      Return ONLY a JSON array.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_FAST,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Talent scout error", error);
    return [];
  }
}

/**
 * Generates a personalized growth plan from current role to target role.
 */
export const generateGrowthPlan = async (currentRole: string, targetRole: string): Promise<GrowthPlan> => {
  try {
    const prompt = `
      You are a senior career architect. Create a strategic growth roadmap for someone currently working as a "${currentRole}" who wants to become a "${targetRole}".
      
      Output Requirements:
      Return a JSON object with:
      1. "milestones": An array of 4 distinct steps (objects). Each step must have:
         - "title": Name of the phase (e.g., "Foundational Skills", "Leadership").
         - "description": 1 sentence summary.
         - "duration": Estimated time (e.g., "3 months").
         - "skills": Array of 3 key skills to master.
         - "resources": Array of 2 specific courses, books, or project ideas.
      2. "habits": An array of 3 daily/weekly habits that will accelerate this growth.

      The first milestone should be "in-progress" status, others "locked".
    `;

    const response = await ai.models.generateContent({
      model: MODEL_FAST,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    
    const data = JSON.parse(text);
    
    // Enrich with IDs and status if AI missed it
    const milestones = data.milestones.map((m: any, i: number) => ({
      ...m,
      id: `m-${i}`,
      status: i === 0 ? 'in-progress' : 'locked'
    }));

    return {
      targetRole,
      milestones,
      habits: data.habits || []
    };
  } catch (error) {
    console.error("Growth plan error", error);
    throw error;
  }
};

/**
 * Searches for professional connections based on a query.
 */
export const getNetworkSuggestions = async (query: string): Promise<NetworkProfile[]> => {
  try {
    const prompt = `
      Generate 6 realistic professional profiles for a networking app based on the search query: "${query || 'software technology leaders'}".
      
      For each profile return a JSON object with:
      - id: unique string
      - name: Full Name
      - role: Current Job Title
      - company: Company Name
      - location: City, Country
      - avatar: initials (2 letters)
      - skills: array of 3 top skills
      - bio: A brief 1-sentence professional tagline.
      - isConnected: boolean (randomly true or false)
      - mutualConnections: integer between 0 and 50

      Return ONLY a JSON array.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_FAST,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Network search error", error);
    return [];
  }
};
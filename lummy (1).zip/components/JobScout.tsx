
import React, { useState, useEffect, useRef } from 'react';
import { Job, AppView, ScoutLog, AutoPilotConfig, JobApplication, ApplicationStatus } from '../types';
import { Search, MapPin, DollarSign, ArrowRight, Sparkles, Cpu, Heart, Briefcase, User, ExternalLink, Mail, CheckCircle, Zap, Globe, Terminal, Play, Pause, Settings, LayoutGrid, List, Clock, Filter, AlertCircle, ChevronDown, Bookmark, AtSign, X } from 'lucide-react';
import { analyzeJobMatch, generateCandidateProfile, CandidateProfile } from '../services/geminiService';
import { dataService } from '../services/dataService';

interface JobScoutProps {
  onSelectJob: (job: Job) => void;
  onNavigate: (view: AppView) => void;
}

const parseSalaryString = (str: string): number | null => {
  if (!str) return null;
  const normalized = str.toLowerCase().replace(/[$,]/g, '').trim();
  if (!normalized) return null;
  
  // Handle "150k" -> 150000
  const kMatch = normalized.match(/(\d+(?:\.\d+)?)\s*k/);
  if (kMatch) {
    return parseFloat(kMatch[1]) * 1000;
  }
  
  // Handle "150000"
  const numMatch = normalized.match(/(\d+(?:\.\d+)?)/);
  if (numMatch) {
    return parseFloat(numMatch[1]);
  }
  
  return null;
};

const parseJobSalary = (salaryStr: string) => {
  if (salaryStr.toLowerCase().includes('competitive')) return { min: 0, max: Infinity };
  
  const normalized = salaryStr.toLowerCase().replace(/[$,]/g, '').trim();
  const regex = /(\d+(?:\.\d+)?)\s*(k)?/gi;
  let match;
  const values: number[] = [];
  
  while ((match = regex.exec(normalized)) !== null) {
      let val = parseFloat(match[1]);
      if (match[2] === 'k') val *= 1000;
      values.push(val);
  }
  
  if (values.length === 0) return { min: 0, max: Infinity };
  if (values.length === 1) return { min: values[0], max: Infinity };
  return { min: Math.min(...values), max: Math.max(...values) };
};

const JobScout: React.FC<JobScoutProps> = ({ onSelectJob, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'BROWSE' | 'SAVED' | 'AUTOPILOT' | 'HISTORY'>('BROWSE');
  
  // -- BROWSE STATE --
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [insight, setInsight] = useState<string>("");
  const [candidateProfile, setCandidateProfile] = useState<CandidateProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [jobsLoading, setJobsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('All');
  const [applied, setApplied] = useState(false);
  
  // -- FILTER STATE --
  const [showFilters, setShowFilters] = useState(false);
  const [salaryMin, setSalaryMin] = useState('');
  const [salaryMax, setSalaryMax] = useState('');

  // -- HISTORY STATE --
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // -- AUTOPILOT STATE --
  const [pilotState, setPilotState] = useState<'IDLE' | 'RUNNING' | 'PAUSED' | 'COMPLETED'>('IDLE');
  const [config, setConfig] = useState<AutoPilotConfig>({
    roles: 'Senior Frontend Engineer, React Developer',
    locations: 'Remote, San Francisco, New York',
    salaryMin: '140000',
    remoteOnly: true,
    platforms: { linkedin: true, indeed: true, glassdoor: true },
    notificationEmail: 'alex@lummy.ai'
  });
  const [emailError, setEmailError] = useState('');
  const [logs, setLogs] = useState<ScoutLog[]>([]);
  const [stats, setStats] = useState({ scanned: 0, matched: 0, applied: 0 });
  const [showStopConfirm, setShowStopConfirm] = useState(false);
  const logContainerRef = useRef<HTMLDivElement>(null);

  // -- BROWSE LOGIC --
  useEffect(() => {
    const fetchJobs = async () => {
      setJobsLoading(true);
      const data = await dataService.getJobs();
      setJobs(data);
      setJobsLoading(false);
    };
    fetchJobs();
  }, [activeTab]); // Refetch when tab changes to ensure saved status is up to date

  // Debounce search input
  useEffect(() => {
    const handler = setTimeout(() => {
      setSearchQuery(searchTerm);
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [searchTerm]);

  // -- HISTORY LOGIC --
  const fetchApplications = async () => {
    setHistoryLoading(true);
    const data = await dataService.getApplications();
    setApplications(data);
    setHistoryLoading(false);
  };

  useEffect(() => {
    if (activeTab === 'HISTORY') {
        fetchApplications();
    }
  }, [activeTab]);

  const uniqueLocations = ['All', ...Array.from(new Set(jobs.map(job => job.location)))];

  const filteredJobs = jobs.filter(job => {
    // Location
    const matchesLoc = locationFilter === 'All' || job.location === locationFilter;
    
    // Search
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          job.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Saved
    const matchesSaved = activeTab === 'SAVED' ? job.saved === true : true;
    
    // Salary
    const jobSal = parseJobSalary(job.salary);
    const userMin = parseSalaryString(salaryMin) || 0;
    const userMax = parseSalaryString(salaryMax) || Infinity;
    
    // Logic: Job range overlaps with User range.
    // Or simplified: Job Max >= User Min AND Job Min <= User Max
    const matchesSalary = (jobSal.max >= userMin) && (jobSal.min <= userMax);

    return matchesLoc && matchesSearch && matchesSaved && matchesSalary;
  });

  const handleJobClick = async (job: Job) => {
    setSelectedJob(job);
    setInsight("");
    setCandidateProfile(null);
    setApplied(false);
    setLoading(true);

    const mockResume = "Senior React Developer with 5 years experience in building scalable web apps.";
    
    try {
      const [insightResult, profileResult] = await Promise.all([
        analyzeJobMatch(mockResume, job.description),
        generateCandidateProfile(job.description, job.requirements)
      ]);
      
      setInsight(insightResult);
      setCandidateProfile(profileResult);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleSave = async (e: React.MouseEvent, job: Job) => {
    e.stopPropagation();
    const newStatus = await dataService.toggleJobSave(job.id);
    setJobs(prev => prev.map(j => j.id === job.id ? { ...j, saved: newStatus } : j));
    if (selectedJob && selectedJob.id === job.id) {
        setSelectedJob(prev => prev ? { ...prev, saved: newStatus } : null);
    }
  };

  const handleApply = async () => {
    if (!selectedJob) return;
    setApplied(true);
    
    // Save to History
    await dataService.trackApplication(selectedJob, 'Manual');

    // Notify
    await dataService.createNotification({
        title: 'Application Received',
        message: `We have sent a confirmation email to alex@lummy.ai regarding your application for ${selectedJob.title}.`,
        type: 'email',
        targetRole: 'CANDIDATE'
    });
    
    if (selectedJob.applyLink && selectedJob.applyLink !== '#') {
        window.open(selectedJob.applyLink, '_blank');
    }
  };

  const handleStatusUpdate = async (id: string, newStatus: ApplicationStatus) => {
    await dataService.updateApplicationStatus(id, newStatus);
    setApplications(prev => prev.map(app => app.id === id ? { ...app, status: newStatus } : app));
  };

  const clearFilters = () => {
    setSalaryMin('');
    setSalaryMax('');
  };

  // -- AUTOPILOT SIMULATION LOGIC --
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (pilotState === 'RUNNING') {
      interval = setInterval(async () => {
        const actions: ScoutLog['action'][] = ['SCAN', 'SCAN', 'MATCH', 'SCAN', 'TAILOR', 'APPLY', 'EMAIL'];
        const platforms = Object.keys(config.platforms).filter(k => config.platforms[k as keyof typeof config.platforms]);
        const randomPlatform = platforms[Math.floor(Math.random() * platforms.length)] || 'Web';
        const randomAction = actions[Math.floor(Math.random() * actions.length)];
        
        let newLog: ScoutLog = {
          id: Date.now().toString(),
          timestamp: Date.now(),
          action: randomAction,
          message: '',
          status: 'success'
        };

        if (randomAction === 'SCAN') {
           newLog.message = `Scanning ${randomPlatform.charAt(0).toUpperCase() + randomPlatform.slice(1)} for new listings...`;
           newLog.status = 'processing';
           setStats(prev => ({ ...prev, scanned: prev.scanned + Math.floor(Math.random() * 5) + 1 }));
        } else if (randomAction === 'MATCH') {
           const companies = ['TechFlow', 'DataMinds', 'CloudScale', 'Aether', 'Orbit'];
           const company = companies[Math.floor(Math.random() * companies.length)];
           newLog.message = `Found High Match: ${company} (92% match score)`;
           newLog.details = company;
           setStats(prev => ({ ...prev, matched: prev.matched + 1 }));
        } else if (randomAction === 'TAILOR') {
           newLog.message = `Auto-sculpting Resume v${stats.applied + 1}.pdf for keyword optimization...`;
           newLog.status = 'processing';
        } else if (randomAction === 'APPLY') {
           newLog.message = `Submitting application form via ${randomPlatform} Easy Apply...`;
           setStats(prev => ({ ...prev, applied: prev.applied + 1 }));
           
           // Occasionally add a real "mock" application to history for effect
           if (Math.random() > 0.7) {
             const mockJob: Job = {
               id: Date.now().toString(),
               title: config.roles.split(',')[0] || 'Senior Engineer',
               company: `Auto-Scout Co ${Math.floor(Math.random() * 100)}`,
               location: 'Remote',
               salary: '$150k+',
               matchScore: 95,
               description: 'Auto-applied by Lummy Agent',
               requirements: [],
               posted: 'Just now',
               saved: false
             };
             await dataService.trackApplication(mockJob, 'Lummy Auto-Pilot');
           }

        } else if (randomAction === 'EMAIL') {
           newLog.message = `Sending personalized cover letter to hiring manager...`;
        }

        setLogs(prev => [...prev, newLog]);

        // Auto scroll logs
        if (logContainerRef.current) {
          logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }

      }, 1500); // New log every 1.5s
    }

    return () => clearInterval(interval);
  }, [pilotState, config, stats]);

  const validateEmail = (email: string) => {
    // Robust email regex
    return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setConfig({...config, notificationEmail: val});
    if (val && !validateEmail(val)) {
        setEmailError('Invalid email format');
    } else {
        setEmailError('');
    }
  };

  const togglePilot = () => {
    if (emailError || !config.notificationEmail) {
      setEmailError('Please provide a valid email before starting.');
      return;
    }
    if (pilotState === 'RUNNING') setPilotState('PAUSED');
    else setPilotState('RUNNING');
  };

  const clearLogs = () => {
    setLogs([]);
    setStats({ scanned: 0, matched: 0, applied: 0 });
    setPilotState('IDLE');
    setShowStopConfirm(false);
  };

  // -- RENDER HELPERS --
  const renderLogIcon = (action: ScoutLog['action']) => {
    switch (action) {
      case 'SCAN': return <Globe size={14} className="text-blue-400" />;
      case 'MATCH': return <Sparkles size={14} className="text-amber-400" />;
      case 'TAILOR': return <Cpu size={14} className="text-purple-400" />;
      case 'APPLY': return <Zap size={14} className="text-emerald-400" />;
      case 'EMAIL': return <Mail size={14} className="text-slate-400" />;
      default: return <Terminal size={14} />;
    }
  };

  const renderStatusBadge = (status: ApplicationStatus) => {
    const styles = {
      'APPLIED': 'bg-slate-700 text-slate-300 border-slate-600',
      'SCREENING': 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
      'INTERVIEW': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      'OFFER': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      'REJECTED': 'bg-red-500/10 text-red-400 border-red-500/20'
    };
    return (
      <span className={`px-2 py-1 rounded-md text-xs font-medium border ${styles[status] || styles['APPLIED']}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      
      {/* Tab Switcher */}
      <div className="flex items-center gap-4 mb-6 border-b border-slate-700/50 pb-2">
        <button 
          onClick={() => setActiveTab('BROWSE')}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === 'BROWSE' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <LayoutGrid size={16} /> Browse Board
        </button>
        <button 
          onClick={() => setActiveTab('SAVED')}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === 'SAVED' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Bookmark size={16} fill={activeTab === 'SAVED' ? 'currentColor' : 'none'} /> Saved Jobs
        </button>
        <button 
          onClick={() => setActiveTab('HISTORY')}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === 'HISTORY' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Clock size={16} /> Application History
        </button>
        <button 
          onClick={() => setActiveTab('AUTOPILOT')}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
            activeTab === 'AUTOPILOT' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Zap size={16} /> AI Auto-Pilot <span className="text-[10px] bg-white/20 px-1.5 rounded">BETA</span>
        </button>
      </div>

      {activeTab === 'AUTOPILOT' ? (
        <div className="flex-1 flex gap-6 overflow-hidden animate-fade-in relative">
          {/* Configuration Panel */}
          <div className="w-1/3 flex flex-col bg-slate-800/30 border border-slate-700/50 rounded-2xl p-6 overflow-y-auto">
             <div className="flex items-center gap-3 mb-6">
               <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                 <Zap size={20} className="text-emerald-400" />
               </div>
               <div>
                 <h2 className="text-xl font-light text-white">Mission Control</h2>
                 <p className="text-xs text-slate-400">Configure your automated agent</p>
               </div>
             </div>

             <div className="space-y-5">
               <div>
                 <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Target Roles</label>
                 <input 
                   value={config.roles}
                   onChange={e => setConfig({...config, roles: e.target.value})}
                   className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-emerald-500"
                 />
               </div>
               
               <div>
                 <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Locations</label>
                 <input 
                   value={config.locations}
                   onChange={e => setConfig({...config, locations: e.target.value})}
                   className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-emerald-500"
                 />
               </div>

               <div>
                 <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Min. Salary (USD)</label>
                 <div className="relative">
                   <span className="absolute left-3 top-2.5 text-slate-500">$</span>
                   <input 
                    value={config.salaryMin}
                    onChange={e => setConfig({...config, salaryMin: e.target.value})}
                    type="number"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-6 pr-3 py-2 text-white text-sm focus:outline-none focus:border-emerald-500"
                   />
                 </div>
               </div>

               <div>
                 <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Notification Email</label>
                 <div className="relative">
                   <span className="absolute left-3 top-2.5 text-slate-500"><AtSign size={14} /></span>
                   <input 
                    value={config.notificationEmail}
                    onChange={handleEmailChange}
                    type="email"
                    placeholder="report@example.com"
                    className={`w-full bg-slate-900 border rounded-xl pl-9 pr-3 py-2 text-white text-sm focus:outline-none transition-colors ${emailError ? 'border-red-500 focus:border-red-500' : 'border-slate-700 focus:border-emerald-500'}`}
                   />
                 </div>
                 {emailError && <p className="text-xs text-red-400 mt-1">{emailError}</p>}
               </div>

               <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Scout Platforms</label>
                  <div className="space-y-2">
                    {Object.keys(config.platforms).map(platform => (
                      <div key={platform} className="flex items-center gap-3 bg-slate-900/50 p-2 rounded-lg border border-slate-700/50">
                         <input 
                           type="checkbox" 
                           checked={config.platforms[platform as keyof typeof config.platforms]}
                           onChange={() => setConfig({
                             ...config, 
                             platforms: { 
                               ...config.platforms, 
                               [platform]: !config.platforms[platform as keyof typeof config.platforms] 
                             }
                           })}
                           className="w-4 h-4 rounded border-slate-600 text-emerald-600 focus:ring-emerald-500 bg-slate-800"
                         />
                         <span className="text-sm text-slate-300 capitalize">{platform}</span>
                      </div>
                    ))}
                  </div>
               </div>
             </div>

             <div className="mt-auto pt-6">
                {pilotState === 'IDLE' ? (
                   <button 
                     onClick={togglePilot}
                     disabled={!!emailError || !config.notificationEmail}
                     className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-xl font-medium transition-all shadow-lg shadow-emerald-900/20 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                   >
                     <Play size={18} fill="currentColor" /> Start Mission
                   </button>
                ) : (
                  <div className="flex gap-3">
                     <button 
                       onClick={togglePilot}
                       className={`flex-1 py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                         pilotState === 'RUNNING' 
                           ? 'bg-amber-600 hover:bg-amber-500 text-white' 
                           : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                       }`}
                     >
                       {pilotState === 'RUNNING' ? <><Pause size={18} fill="currentColor" /> Pause</> : <><Play size={18} fill="currentColor" /> Resume</>}
                     </button>
                     <button 
                       onClick={() => setShowStopConfirm(true)}
                       className="px-4 bg-slate-700 hover:bg-slate-600 text-white rounded-xl"
                     >
                       Stop
                     </button>
                  </div>
                )}
             </div>
          </div>

          {/* Visualization & Logs */}
          <div className="flex-1 flex flex-col gap-6">
             {/* Stats Cards */}
             <div className="grid grid-cols-3 gap-4">
               <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400">
                    <Globe size={20} />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">{stats.scanned}</div>
                    <div className="text-xs text-slate-400">Jobs Scanned</div>
                  </div>
               </div>
               <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-400">
                    <Sparkles size={20} />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">{stats.matched}</div>
                    <div className="text-xs text-slate-400">High Matches</div>
                  </div>
               </div>
               <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Zap size={20} />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">{stats.applied}</div>
                    <div className="text-xs text-slate-400">Auto-Applied</div>
                  </div>
               </div>
             </div>

             {/* Terminal View */}
             <div className="flex-1 bg-slate-950 rounded-2xl border border-slate-800 p-4 font-mono text-sm overflow-hidden flex flex-col shadow-2xl relative">
                <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-2">
                   <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                   <div className="w-3 h-3 rounded-full bg-amber-500/50"></div>
                   <div className="w-3 h-3 rounded-full bg-emerald-500/50"></div>
                   <span className="ml-2 text-slate-500 text-xs">scout_agent_v2.log</span>
                   {pilotState === 'RUNNING' && <span className="ml-auto flex items-center gap-2 text-emerald-400 text-xs"><span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span> LIVE</span>}
                </div>
                
                <div ref={logContainerRef} className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                  {logs.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-700">
                      <Terminal size={48} className="mb-4 opacity-50" />
                      <p>Agent is idle. Initialize mission to start scanning.</p>
                    </div>
                  ) : (
                    logs.map(log => (
                      <div key={log.id} className="flex gap-3 text-slate-300 animate-fade-in-up">
                        <span className="text-slate-600 shrink-0">[{new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' })}]</span>
                        <span className="shrink-0 pt-0.5">{renderLogIcon(log.action)}</span>
                        <span className={`flex-1 ${log.action === 'MATCH' ? 'text-emerald-300 font-semibold' : ''} ${log.action === 'APPLY' ? 'text-indigo-300' : ''}`}>
                          {log.message}
                        </span>
                        {log.status === 'success' && <CheckCircle size={14} className="text-emerald-500/50 shrink-0" />}
                      </div>
                    ))
                  )}
                  {pilotState === 'RUNNING' && (
                    <div className="animate-pulse text-emerald-500/50">_</div>
                  )}
                </div>
             </div>
          </div>

          {/* Stop Confirmation Modal */}
          {showStopConfirm && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm rounded-none">
                <div className="bg-slate-900 border border-slate-700 p-6 rounded-xl shadow-2xl max-w-sm text-center mx-4 animate-fade-in-up">
                    <div className="w-12 h-12 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4 text-red-400">
                        <AlertCircle size={24} />
                    </div>
                    <h3 className="text-white text-lg font-semibold mb-2">Stop Mission</h3>
                    <p className="text-slate-400 text-sm mb-6">Are you sure you want to stop the mission?</p>
                    <div className="flex gap-3 justify-center">
                        <button 
                            onClick={() => setShowStopConfirm(false)}
                            className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors border border-slate-700 font-medium text-sm"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={clearLogs}
                            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-colors font-medium text-sm shadow-lg shadow-red-900/20"
                        >
                            Confirm Stop
                        </button>
                    </div>
                </div>
            </div>
          )}
        </div>
      ) : activeTab === 'HISTORY' ? (
        // -- HISTORY VIEW --
        <div className="flex-1 flex flex-col bg-slate-800/30 border border-slate-700/50 rounded-2xl p-6 overflow-hidden animate-fade-in">
           <header className="mb-6 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-light text-white mb-1">Application History</h2>
                <p className="text-slate-400 text-sm">Track the status of your manual and AI-submitted applications.</p>
              </div>
              <div className="flex gap-2">
                <button className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 text-sm border border-slate-700 transition-colors">
                  <Filter size={14} /> Filter Status
                </button>
              </div>
           </header>

           <div className="flex-1 overflow-y-auto pr-2">
             <table className="w-full text-left border-collapse">
               <thead>
                 <tr className="text-xs text-slate-500 uppercase tracking-wider border-b border-slate-700">
                   <th className="pb-3 pl-4 font-semibold">Role & Company</th>
                   <th className="pb-3 font-semibold">Applied Date</th>
                   <th className="pb-3 font-semibold">Platform</th>
                   <th className="pb-3 font-semibold">Salary Range</th>
                   <th className="pb-3 font-semibold">Status</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-800">
                 {historyLoading ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-500">Loading history...</td>
                    </tr>
                 ) : applications.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-500 flex flex-col items-center justify-center">
                         <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mb-3">
                           <Briefcase size={20} className="opacity-50" />
                         </div>
                         <p>No applications found yet.</p>
                      </td>
                    </tr>
                 ) : (
                   applications.map(app => (
                     <tr key={app.id} className="group hover:bg-slate-800/40 transition-colors">
                       <td className="py-4 pl-4">
                         <div className="font-medium text-white">{app.title}</div>
                         <div className="text-xs text-slate-400">{app.company} • {app.location}</div>
                       </td>
                       <td className="py-4 text-sm text-slate-400">
                         {new Date(app.dateApplied).toLocaleDateString()}
                       </td>
                       <td className="py-4">
                         <span className={`text-xs px-2 py-1 rounded border ${
                           app.platform === 'Lummy Auto-Pilot' 
                             ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                             : 'bg-slate-700/50 text-slate-300 border-slate-600/50'
                         }`}>
                           {app.platform}
                         </span>
                       </td>
                       <td className="py-4 text-sm text-slate-400">{app.salary}</td>
                       <td className="py-4">
                         <div className="group/status relative inline-block">
                           <button className="flex items-center gap-2">
                             {renderStatusBadge(app.status)}
                             <ChevronDown size={12} className="text-slate-600 opacity-0 group-hover/status:opacity-100 transition-opacity" />
                           </button>
                           {/* Status Dropdown */}
                           <div className="absolute top-full left-0 mt-1 w-32 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-20 hidden group-hover/status:block">
                              {['APPLIED', 'SCREENING', 'INTERVIEW', 'OFFER', 'REJECTED'].map((s) => (
                                <button 
                                  key={s}
                                  onClick={() => handleStatusUpdate(app.id, s as ApplicationStatus)}
                                  className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:bg-slate-700 hover:text-white first:rounded-t-lg last:rounded-b-lg"
                                >
                                  {s}
                                </button>
                              ))}
                           </div>
                         </div>
                       </td>
                     </tr>
                   ))
                 )}
               </tbody>
             </table>
           </div>
        </div>
      ) : (
        // -- BROWSE OR SAVED VIEW --
        <div className="flex-1 flex gap-6 overflow-hidden animate-fade-in">
          {/* Job List */}
          <div className="w-1/3 flex flex-col gap-4 overflow-y-auto pr-2">
            
            {/* Location Filters */}
            <div className="mb-4">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 block pl-1">Filter by Location</label>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {uniqueLocations.map(loc => (
                  <button
                    key={loc}
                    onClick={() => setLocationFilter(loc)}
                    className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                      locationFilter === loc 
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-900/20' 
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700 hover:text-white hover:border-slate-600'
                    }`}
                  >
                    {loc}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-2 mb-2 items-center">
              <div className="relative flex-1">
                <input 
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search for your next role..." 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-indigo-500 transition-colors"
                />
                <Search className="absolute left-3 top-3.5 text-slate-500" size={18} />
              </div>
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className={`p-3 rounded-xl border transition-colors ${showFilters ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'}`}
                title="Advanced Filters"
              >
                <Filter size={18} />
              </button>
            </div>

            {showFilters && (
               <div className="mb-4 p-4 bg-slate-800/40 border border-slate-700 rounded-xl animate-fade-in text-sm relative">
                    <button 
                        onClick={clearFilters}
                        className="absolute top-2 right-2 text-slate-500 hover:text-white p-1 rounded-full hover:bg-slate-700 transition-colors"
                        title="Clear Filters"
                    >
                        <X size={14} />
                    </button>
                   <div className="flex items-center gap-4">
                        <div className="flex-1">
                            <label className="block text-xs text-slate-500 mb-1 font-medium">Min Salary</label>
                            <div className="relative">
                               <span className="absolute left-3 top-2 text-slate-500">$</span>
                               <input 
                                   type="text" 
                                   value={salaryMin} 
                                   onChange={e => setSalaryMin(e.target.value)}
                                   placeholder="e.g. 100k"
                                   className="w-full bg-slate-900 border border-slate-700 rounded-lg py-1.5 pl-6 pr-3 text-white focus:border-indigo-500 focus:outline-none" 
                               />
                            </div>
                        </div>
                        <div className="flex-1">
                            <label className="block text-xs text-slate-500 mb-1 font-medium">Max Salary</label>
                            <div className="relative">
                               <span className="absolute left-3 top-2 text-slate-500">$</span>
                               <input 
                                   type="text" 
                                   value={salaryMax} 
                                   onChange={e => setSalaryMax(e.target.value)}
                                   placeholder="Any"
                                   className="w-full bg-slate-900 border border-slate-700 rounded-lg py-1.5 pl-6 pr-3 text-white focus:border-indigo-500 focus:outline-none" 
                               />
                            </div>
                        </div>
                   </div>
               </div>
            )}

            {jobsLoading ? (
              <div className="space-y-4">
                 {[1,2,3].map(i => (
                   <div key={i} className="h-32 bg-slate-800/40 border border-slate-700/50 rounded-xl animate-pulse"></div>
                 ))}
              </div>
            ) : filteredJobs.length > 0 ? (
              filteredJobs.map((job) => (
                <div 
                  key={job.id}
                  onClick={() => handleJobClick(job)}
                  className={`p-5 rounded-xl border cursor-pointer transition-all duration-200 group relative ${
                    selectedJob?.id === job.id 
                      ? 'bg-indigo-900/20 border-indigo-500/50 shadow-lg shadow-indigo-900/10' 
                      : 'bg-slate-800/40 border-slate-700/50 hover:bg-slate-800/80 hover:border-slate-600'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className={`font-semibold text-lg max-w-[85%] ${selectedJob?.id === job.id ? 'text-indigo-300' : 'text-slate-200 group-hover:text-white'}`}>
                      {job.title}
                    </h3>
                    <div className="flex items-center gap-2">
                       <button
                         onClick={(e) => handleToggleSave(e, job)}
                         className={`p-1 rounded-full transition-colors z-10 ${job.saved ? 'text-amber-400 hover:bg-amber-400/10' : 'text-slate-600 hover:text-slate-400 hover:bg-slate-700'}`}
                       >
                         <Bookmark size={18} fill={job.saved ? "currentColor" : "none"} />
                       </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mb-3">
                    <p className="text-slate-400 font-medium">{job.company}</p>
                    <span className="text-xs bg-slate-700/50 text-slate-400 px-2 py-1 rounded">
                      {job.posted}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-slate-500 mb-3">
                    <div className="flex items-center gap-1">
                      <MapPin size={14} /> {job.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign size={14} /> {job.salary}
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex gap-2">
                      {job.requirements.slice(0, 2).map(req => (
                        <span key={req} className="text-xs px-2 py-1 rounded-md bg-slate-700/30 text-slate-400 border border-slate-700">
                          {req}
                        </span>
                      ))}
                      {job.requirements.length > 2 && (
                        <span className="text-xs px-2 py-1 rounded-md bg-slate-700/30 text-slate-400 border border-slate-700">
                        +{job.requirements.length - 2}
                      </span>
                      )}
                    </div>
                    <div className="text-emerald-400 font-bold text-sm flex items-center gap-1">
                      {job.matchScore}% <span className="text-slate-600 font-normal">Match</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-10 text-slate-500">
                <Search size={32} className="mx-auto mb-2 opacity-50" />
                <p>No jobs found matching your criteria.</p>
                {activeTab === 'SAVED' && <p className="text-xs mt-2">Bookmark jobs from the Browse tab to see them here.</p>}
              </div>
            )}
          </div>

          {/* Job Details */}
          <div className="flex-1 bg-slate-800/30 rounded-2xl border border-slate-700/50 p-8 overflow-y-auto">
            {selectedJob ? (
              <div className="animate-fade-in">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-3xl font-light text-white mb-2">{selectedJob.title}</h2>
                    <div className="text-xl text-indigo-400 mb-4 flex items-center gap-2">
                       {selectedJob.company}
                       {selectedJob.saved && <span className="text-xs bg-amber-500/10 text-amber-400 px-2 py-1 rounded border border-amber-500/20 flex items-center gap-1"><Bookmark size={10} fill="currentColor" /> Saved</span>}
                    </div>
                  </div>
                  <div className="flex flex-col gap-3 items-end">
                    <div className="flex gap-3">
                       <button
                         onClick={(e) => handleToggleSave(e, selectedJob)}
                         className={`px-3 py-2 rounded-lg transition-colors border flex items-center justify-center ${
                             selectedJob.saved 
                               ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20' 
                               : 'bg-slate-700 hover:bg-slate-600 text-slate-300 border-slate-600'
                         }`}
                         title={selectedJob.saved ? "Remove from Saved" : "Save for Later"}
                       >
                         <Bookmark size={18} fill={selectedJob.saved ? "currentColor" : "none"} />
                       </button>
                      <button 
                        onClick={() => {
                          onSelectJob(selectedJob);
                          onNavigate(AppView.REHEARSE);
                        }}
                        className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors flex items-center gap-2 border border-slate-600"
                      >
                        <Sparkles size={16} /> Rehearse
                      </button>
                      <button 
                        onClick={() => {
                          onSelectJob(selectedJob);
                          onNavigate(AppView.ARCHITECT);
                        }}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors flex items-center gap-2 shadow-lg shadow-indigo-900/20"
                      >
                        Sculpt CV <ArrowRight size={16} />
                      </button>
                    </div>
                    {applied ? (
                       <div className="w-full px-4 py-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg flex items-center justify-center gap-2 font-medium cursor-default">
                          <CheckCircle size={16} /> Application Tracked
                       </div>
                    ) : (
                      <button 
                        onClick={handleApply}
                        className="w-full px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/20 font-medium"
                      >
                        Apply Now <ExternalLink size={16} />
                      </button>
                    )}
                  </div>
                </div>

                {/* Lummy Insight */}
                <div className="bg-slate-900/50 rounded-xl p-5 mb-6 border border-slate-800 relative overflow-hidden">
                   <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-indigo-500 to-purple-500"></div>
                   <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                     <Sparkles size={14} className="text-indigo-400" /> Lummy Insight
                   </h4>
                   {loading ? (
                     <div className="text-slate-500 animate-pulse">Analyzing resonance between your profile and this opportunity...</div>
                   ) : (
                     <p className="text-slate-300 leading-relaxed italic">"{insight}"</p>
                   )}
                </div>

                {/* Ideal Candidate Profile */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-white mb-4">Target Profile</h3>

                  {/* Persona Summary */}
                  <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-5 mb-4">
                    <div className="flex items-center gap-2 text-indigo-400 mb-2 font-medium text-sm">
                       <User size={18} /> Profile Summary
                    </div>
                    {loading || !candidateProfile ? (
                       <div className="space-y-2">
                         <div className="h-4 bg-slate-700/30 rounded w-full animate-pulse"></div>
                         <div className="h-4 bg-slate-700/30 rounded w-3/4 animate-pulse"></div>
                       </div>
                    ) : (
                       <p className="text-slate-300 text-sm leading-relaxed">{candidateProfile.summary}</p>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Technical */}
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-5">
                      <div className="flex items-center gap-2 text-blue-400 mb-3 font-medium text-sm">
                        <Cpu size={18} /> Technical Skills
                      </div>
                      {loading || !candidateProfile ? (
                        <div className="h-20 bg-slate-700/30 rounded animate-pulse"></div>
                      ) : (
                        <p className="text-slate-300 text-sm leading-relaxed">{candidateProfile.technical}</p>
                      )}
                    </div>

                    {/* Experience */}
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-5">
                      <div className="flex items-center gap-2 text-emerald-400 mb-3 font-medium text-sm">
                        <Briefcase size={18} /> Experience
                      </div>
                       {loading || !candidateProfile ? (
                        <div className="h-20 bg-slate-700/30 rounded animate-pulse"></div>
                      ) : (
                        <p className="text-slate-300 text-sm leading-relaxed">{candidateProfile.experience}</p>
                      )}
                    </div>

                    {/* Cultural */}
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-5">
                      <div className="flex items-center gap-2 text-pink-400 mb-3 font-medium text-sm">
                        <Heart size={18} /> Cultural Fit
                      </div>
                       {loading || !candidateProfile ? (
                        <div className="h-24 bg-slate-700/30 rounded animate-pulse"></div>
                      ) : (
                        <p className="text-slate-300 text-sm leading-relaxed">{candidateProfile.cultural}</p>
                      )}
                    </div>

                    {/* Soft Skills */}
                    <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-5">
                      <div className="flex items-center gap-2 text-amber-400 mb-3 font-medium text-sm">
                        <Sparkles size={18} /> Soft Skills & Traits
                      </div>
                       {loading || !candidateProfile ? (
                        <div className="flex gap-2 flex-wrap">
                           {[1,2,3,4].map(i => <div key={i} className="h-8 w-20 bg-slate-700/30 rounded animate-pulse"></div>)}
                        </div>
                      ) : (
                        <div className="flex flex-wrap gap-2">
                           {candidateProfile.softSkills && candidateProfile.softSkills.map((skill, i) => (
                             <span key={i} className="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-medium">
                               {skill}
                             </span>
                           ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Key Requirements */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-white mb-4">Key Requirements</h3>
                  <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6">
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {selectedJob.requirements.map((req, i) => (
                        <li key={i} className="flex items-start gap-3 text-slate-300">
                          <span className="mt-2 w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></span>
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="space-y-6">
                  <section>
                    <h3 className="text-lg font-semibold text-white mb-3">About the Role</h3>
                    <p className="text-slate-300 leading-relaxed">
                      {selectedJob.description}
                    </p>
                  </section>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 opacity-50">
                <Search size={48} className="mb-4" />
                <p>Select a role to analyze details</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default JobScout;

import React, { useState, useEffect } from 'react';
import { Message } from '../types';
import { Send, User, Search, Paperclip, MoreVertical } from 'lucide-react';
import { dataService } from '../services/dataService';

// Mock Data for Headers (Keep these static for demo UI purposes, but chat connects to DB)
const CONVERSATIONS = [
  { id: '1', name: 'Nebula Stream Recruiter', lastMessage: 'Would 2 PM EST work for the interview?', time: '10:42 AM', unread: 2, avatar: 'NS' },
  { id: '2', name: 'Sarah from Cognitive', lastMessage: 'We were impressed by your portfolio.', time: 'Yesterday', unread: 0, avatar: 'SC' },
  { id: '3', name: 'Aether Design Team', lastMessage: 'Thanks for applying!', time: 'Mon', unread: 0, avatar: 'AD' },
];

const Messaging: React.FC = () => {
  const [activeChat, setActiveChat] = useState<string>('1');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMessages = async () => {
      setLoading(true);
      const data = await dataService.getMessages();
      setMessages(data);
      setLoading(false);
    };
    fetchMessages();
  }, [activeChat]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    // Optimistic update
    const tempMsg: Message = {
        id: Date.now().toString(),
        senderId: 'me',
        senderName: 'Me',
        role: 'user',
        content: input,
        timestamp: Date.now()
    };
    setMessages(prev => [...prev, tempMsg]);
    setInput('');
    
    // Persist
    await dataService.sendMessage(tempMsg.content, 'user', 'Me');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] rounded-2xl border border-slate-800 bg-slate-900/50 backdrop-blur-sm overflow-hidden animate-fade-in">
      {/* Sidebar List */}
      <div className="w-80 border-r border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-800">
          <h2 className="text-white font-semibold mb-4">Messages</h2>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search conversations..." 
              className="w-full bg-slate-800 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
            <Search size={14} className="absolute left-3 top-2.5 text-slate-500" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {CONVERSATIONS.map(convo => (
            <div 
              key={convo.id}
              onClick={() => setActiveChat(convo.id)}
              className={`p-4 flex items-center gap-3 cursor-pointer hover:bg-slate-800/50 transition-colors border-l-2 ${
                activeChat === convo.id ? 'bg-indigo-900/10 border-indigo-500' : 'border-transparent'
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                {convo.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-baseline mb-1">
                  <h4 className={`text-sm font-medium truncate ${activeChat === convo.id ? 'text-white' : 'text-slate-300'}`}>
                    {convo.name}
                  </h4>
                  <span className="text-xs text-slate-500">{convo.time}</span>
                </div>
                <p className={`text-xs truncate ${convo.unread > 0 ? 'text-indigo-300 font-medium' : 'text-slate-500'}`}>
                  {convo.lastMessage}
                </p>
              </div>
              {convo.unread > 0 && (
                <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-slate-900/30">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/80">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                NS
              </div>
              <div>
                <h3 className="text-white font-medium">Nebula Stream Recruiter</h3>
                <span className="text-xs text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Online
                </span>
              </div>
          </div>
          <button className="text-slate-400 hover:text-white">
            <MoreVertical size={20} />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {loading ? (
             <div className="flex items-center justify-center h-full text-slate-500">Loading history...</div>
          ) : messages.length === 0 ? (
             <div className="flex items-center justify-center h-full text-slate-500">No messages yet. Say hello!</div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.role === 'user';
              return (
                <div key={msg.id} className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${isMe ? 'bg-slate-700' : 'bg-indigo-600'}`}>
                     <User size={14} className="text-white" />
                  </div>
                  <div className={`max-w-[70%] p-4 rounded-2xl text-sm leading-relaxed ${
                    isMe 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-slate-800 border border-slate-700 text-slate-200 rounded-tl-none'
                  }`}>
                    {msg.content}
                    <div className={`text-[10px] mt-2 opacity-60 ${isMe ? 'text-indigo-200' : 'text-slate-500'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Input */}
        <div className="p-4 bg-slate-900 border-t border-slate-800">
          <div className="flex items-center gap-2 bg-slate-800 rounded-xl p-2 border border-slate-700">
            <button className="p-2 text-slate-400 hover:text-white transition-colors">
              <Paperclip size={20} />
            </button>
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..." 
              className="flex-1 bg-transparent text-white focus:outline-none placeholder:text-slate-500"
            />
            <button 
              onClick={handleSend}
              className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors shadow-lg shadow-indigo-900/20"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Messaging;
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Users, Clock, Briefcase, CheckCircle, TrendingUp, AlertCircle, ChevronRight } from 'lucide-react';

const activityData = [
  { name: 'Mon', sourced: 12, applied: 24 },
  { name: 'Tue', sourced: 19, applied: 18 },
  { name: 'Wed', sourced: 15, applied: 32 },
  { name: 'Thu', sourced: 22, applied: 28 },
  { name: 'Fri', sourced: 30, applied: 45 },
];

const EmployerDashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header className="mb-8 flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-light text-white mb-2">Talent Command Center</h1>
          <p className="text-slate-400 font-light">Orchestrating the next generation of your workforce.</p>
        </div>
        <div className="text-right">
           <div className="text-2xl font-bold text-emerald-400">12</div>
           <div className="text-xs text-slate-500 uppercase tracking-wider">Interviews Today</div>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-emerald-500/50 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to pipeline')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-emerald-300 transition-colors">Active Pipeline</span>
            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
              <Users size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">142</div>
          <div className="text-xs text-emerald-400 mt-2 flex items-center gap-1">
            <TrendingUp size={12} /> 12 candidates added via Auto-Scout
          </div>
        </div>

        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-indigo-500/50 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to analytics')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-indigo-300 transition-colors">Time to Hire</span>
            <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400 group-hover:bg-indigo-500/20 transition-colors">
              <Clock size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">14d</div>
          <div className="text-xs text-slate-500 mt-2">Market avg: 24d</div>
        </div>

        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-amber-500/50 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to jobs')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-amber-300 transition-colors">Open Positions</span>
            <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400 group-hover:bg-amber-500/20 transition-colors">
              <Briefcase size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">5</div>
          <div className="text-xs text-amber-400 mt-2 flex items-center gap-1">
             <AlertCircle size={12} /> 2 urgent roles
          </div>
        </div>

        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-pink-500/50 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to offers')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-pink-300 transition-colors">Offer Acceptance</span>
            <div className="p-2 bg-pink-500/10 rounded-lg text-pink-400 group-hover:bg-pink-500/20 transition-colors">
              <CheckCircle size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">92%</div>
          <div className="text-xs text-slate-500 mt-2">Last 30 days</div>
        </div>
      </div>

      {/* Main Chart */}
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-slate-800/30 p-8 rounded-2xl border border-slate-700/30 hover:border-slate-700/50 transition-colors">
          <h2 className="text-xl font-light text-white mb-6">Pipeline Velocity</h2>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSourced" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorApplied" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Area type="monotone" dataKey="sourced" name="AI Sourced" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorSourced)" />
                <Area type="monotone" dataKey="applied" name="Organic Applicants" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorApplied)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-800/30 p-8 rounded-2xl border border-slate-700/30 flex flex-col">
           <h2 className="text-xl font-light text-white mb-4">Pending Actions</h2>
           <div className="flex-1 space-y-4 overflow-y-auto">
              {[1, 2, 3].map((i) => (
                <div 
                  key={i} 
                  className="bg-slate-900/50 p-4 rounded-xl border border-slate-700/50 flex items-start gap-3 cursor-pointer hover:bg-slate-800 hover:border-slate-600 transition-all group"
                  onClick={() => console.log('Action clicked')}
                >
                   <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 group-hover:bg-blue-500/30 transition-colors">
                      JS
                   </div>
                   <div className="flex-1">
                      <p className="text-sm text-slate-200 group-hover:text-white transition-colors">Review final offer for <strong>Senior Engineer</strong>.</p>
                      <span className="text-xs text-slate-500">2 hours ago</span>
                   </div>
                   <ChevronRight size={14} className="text-slate-600 group-hover:text-slate-400 opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              ))}
               <div 
                 className="bg-slate-900/50 p-4 rounded-xl border border-slate-700/50 flex items-start gap-3 cursor-pointer hover:bg-slate-800 hover:border-slate-600 transition-all group"
                 onClick={() => console.log('Action clicked')}
               >
                   <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 group-hover:bg-amber-500/30 transition-colors">
                      <Clock size={16} />
                   </div>
                   <div className="flex-1">
                      <p className="text-sm text-slate-200 group-hover:text-white transition-colors">Schedule debrief for Product Lead role.</p>
                      <span className="text-xs text-slate-500">Yesterday</span>
                   </div>
                   <ChevronRight size={14} className="text-slate-600 group-hover:text-slate-400 opacity-0 group-hover:opacity-100 transition-all" />
                </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default EmployerDashboard;
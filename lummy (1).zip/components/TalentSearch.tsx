import React, { useState } from 'react';
import { scoutTalent } from '../services/geminiService';
import { Candidate } from '../types';
import { Search, Sparkles, MapPin, Briefcase, Plus, Linkedin, Globe, Database } from 'lucide-react';

const TalentSearch: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setResults([]); // Clear previous
    const candidates = await scoutTalent(query);
    setResults(candidates);
    setLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] gap-6 animate-fade-in">
      <div className="flex-1 flex flex-col">
        <header className="mb-6">
          <h1 className="text-3xl font-light text-white mb-2">Talent Hunter</h1>
          <p className="text-slate-400">Lummy AI scouts LinkedIn, Indeed, and our internal database to find your perfect match in seconds.</p>
        </header>

        {/* Search Input */}
        <div className="relative mb-8">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="text-slate-500" size={20} />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="e.g. Senior React Developer in San Francisco with 5+ years experience..."
            className="w-full bg-slate-800/50 border border-slate-700 text-white rounded-2xl py-4 pl-12 pr-32 focus:outline-none focus:border-emerald-500 transition-colors shadow-xl"
          />
          <button
            onClick={handleSearch}
            disabled={loading}
            className="absolute right-2 top-2 bottom-2 bg-emerald-600 hover:bg-emerald-500 text-white px-6 rounded-xl font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {loading ? <Sparkles className="animate-spin" size={18} /> : 'Scout'}
          </button>
        </div>

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto pr-2">
          {loading ? (
             <div className="flex flex-col items-center justify-center h-64 text-slate-500 space-y-4">
                <div className="relative">
                   <div className="w-16 h-16 border-4 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin"></div>
                   <div className="absolute inset-0 flex items-center justify-center"><Globe size={24} className="text-emerald-500/50" /></div>
                </div>
                <p className="animate-pulse">Scanning global networks for talent...</p>
             </div>
          ) : results.length > 0 ? (
            <div className="grid grid-cols-1 gap-4">
              {results.map((candidate) => (
                <div key={candidate.id} className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-6 hover:border-emerald-500/30 transition-all group relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4">
                    <div className="flex items-center gap-1 text-emerald-400 bg-emerald-900/20 px-3 py-1 rounded-full border border-emerald-900/50">
                       <Sparkles size={14} />
                       <span className="font-bold">{candidate.matchScore}% Match</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-5">
                    <div className="w-16 h-16 rounded-full bg-slate-700 flex items-center justify-center text-2xl font-bold text-slate-400 border-2 border-slate-600">
                      {candidate.name.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-white mb-1">{candidate.name}</h3>
                      <p className="text-indigo-300 font-medium mb-2">{candidate.role}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-slate-400 mb-3">
                         <span className="flex items-center gap-1"><Briefcase size={14} /> {candidate.experience}</span>
                         <span className="flex items-center gap-1">
                           {candidate.source === 'LinkedIn' && <Linkedin size={14} className="text-blue-400" />}
                           {candidate.source === 'Indeed' && <Globe size={14} className="text-blue-600" />}
                           {candidate.source === 'Database' && <Database size={14} className="text-emerald-400" />}
                           via {candidate.source}
                         </span>
                      </div>

                      <p className="text-slate-300 text-sm italic mb-4 max-w-2xl">"{candidate.bio}"</p>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {candidate.skills.map((skill) => (
                          <span key={skill} className="px-2 py-1 bg-slate-700/50 border border-slate-600 rounded text-xs text-slate-300">
                            {skill}
                          </span>
                        ))}
                      </div>

                      <div className="flex gap-3">
                        <button className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2">
                           <Plus size={16} /> Add to Pipeline
                        </button>
                        <button className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors border border-slate-600">
                           View Full Profile
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-slate-500 opacity-50">
              <Search size={48} className="mb-4" />
              <p>Enter a job description to start hunting.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TalentSearch;
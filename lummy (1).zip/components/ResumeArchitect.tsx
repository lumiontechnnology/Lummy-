
import React, { useState } from 'react';
import { Job } from '../types';
import { tailorResume } from '../services/geminiService';
import { FileText, Wand2, ArrowRight, Download, RefreshCw, CheckCircle, Upload, X } from 'lucide-react';

interface ResumeArchitectProps {
  targetJob: Job | null;
}

const DEFAULT_RESUME = `
Jane Doe
Frontend Developer

Experience:
- Frontend Dev at TechCorp (2020-Present): Built web apps using React.
- Jr Dev at StartUp (2018-2020): Fixed bugs and wrote HTML/CSS.

Skills: React, JavaScript, CSS, HTML.
`;

const ResumeArchitect: React.FC<ResumeArchitectProps> = ({ targetJob }) => {
  const [currentResume, setCurrentResume] = useState(DEFAULT_RESUME);
  const [tailoredResume, setTailoredResume] = useState<string>('');
  const [reasoning, setReasoning] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  const processFile = (uploaded: File) => {
    setFile(uploaded);
    
    // In a real browser environment without backend, we can easily read text files.
    // For PDF/DOCX, parsing purely client-side requires heavy libraries. 
    // For this demo, we simulate extraction for binary files and read text files directly.
    if (uploaded.type === "text/plain") {
        const reader = new FileReader();
        reader.onload = (e) => {
            if (e.target?.result) setCurrentResume(e.target.result as string);
        };
        reader.readAsText(uploaded);
    } else {
        // Mock extraction for PDF/DOCX to allow the flow to continue
        const mockContent = `[Extracted content from ${uploaded.name}]\n\nJane Doe\nSenior Developer\n\nExperience:\n- Senior Engineer at TechCorp (2020-2023)\n- Software Developer at Inc (2018-2020)\n\nSkills: React, Node.js, TypeScript, Cloud Architecture\n\n(Note: This is simulated content for the demo as client-side PDF parsing is limited without external libraries.)`;
        setCurrentResume(mockContent);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const removeFile = () => {
    setFile(null);
    setCurrentResume(DEFAULT_RESUME);
  };

  const handleSculpt = async () => {
    if (!targetJob) return;
    setIsGenerating(true);
    try {
      const result = await tailorResume(currentResume, targetJob.description);
      setTailoredResume(result.tailoredResume);
      setReasoning(result.reasoning);
    } catch (e) {
      console.error(e);
      setReasoning("Transformation failed. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  if (!targetJob) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-500">
        <FileText size={48} className="mb-4 opacity-50" />
        <h2 className="text-xl text-slate-300 mb-2">No Target Selected</h2>
        <p>Navigate to Scout to select a job opportunity first.</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col animate-fade-in">
      <header className="mb-6 flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-light text-white mb-2">Resume Architect</h1>
          <p className="text-slate-400">Targeting: <span className="text-indigo-400 font-medium">{targetJob.title}</span> at {targetJob.company}</p>
        </div>
        {tailoredResume && (
           <button className="flex items-center gap-2 bg-emerald-600/20 text-emerald-400 border border-emerald-600/50 px-4 py-2 rounded-lg hover:bg-emerald-600/30 transition-colors">
             <Download size={18} /> Export PDF
           </button>
        )}
      </header>

      <div className="flex-1 grid grid-cols-2 gap-8 min-h-0">
        {/* Source Column */}
        <div className="flex flex-col gap-4">
          <div className="flex justify-between items-center text-slate-400 text-sm uppercase tracking-wider font-semibold">
            <span>Base Profile</span>
            <button className="text-xs text-indigo-400 hover:text-indigo-300">Import LinkedIn</button>
          </div>

          {/* Upload Area */}
          {!file ? (
            <div 
                className="border-2 border-dashed border-slate-700 hover:border-indigo-500/50 rounded-xl p-8 flex flex-col items-center justify-center text-slate-400 cursor-pointer transition-colors bg-slate-800/30 hover:bg-slate-800/50"
                onClick={() => document.getElementById('resume-upload')?.click()}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
            >
                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mb-3 text-slate-300">
                    <Upload size={20} />
                </div>
                <p className="text-sm font-medium text-slate-300">Upload Resume</p>
                <p className="text-xs text-slate-500 mt-1 mb-2">PDF, DOCX, or TXT</p>
                <input 
                    id="resume-upload" 
                    type="file" 
                    accept=".pdf,.doc,.docx,.txt" 
                    className="hidden" 
                    onChange={handleFileUpload}
                />
            </div>
          ) : (
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 flex items-center justify-between animate-fade-in">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-400">
                        <FileText size={20} />
                    </div>
                    <div className="min-w-0">
                        <p className="text-white text-sm font-medium truncate max-w-[200px]">{file.name}</p>
                        <p className="text-slate-500 text-xs">{(file.size / 1024).toFixed(0)} KB • Ready to extract</p>
                    </div>
                </div>
                <button onClick={removeFile} className="bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-lg transition-colors">
                    <X size={16} />
                </button>
            </div>
          )}

          <div className="relative flex items-center py-2">
              <div className="flex-grow border-t border-slate-800"></div>
              <span className="flex-shrink-0 mx-3 text-slate-600 text-[10px] uppercase font-bold tracking-widest">Or Paste Text</span>
              <div className="flex-grow border-t border-slate-800"></div>
          </div>

          <textarea
            value={currentResume}
            onChange={(e) => setCurrentResume(e.target.value)}
            className="flex-1 bg-slate-800/50 border border-slate-700 rounded-xl p-6 text-slate-300 font-mono text-sm focus:outline-none focus:border-indigo-500 resize-none leading-relaxed"
            placeholder="Paste your current resume here..."
          />
        </div>

        {/* Action & Result Column */}
        <div className="flex flex-col gap-4">
          <div className="flex justify-between items-center text-slate-400 text-sm uppercase tracking-wider font-semibold">
            <span>Metamorphosis</span>
          </div>

          {!tailoredResume ? (
            <div className="flex-1 bg-slate-800/30 border border-slate-700/50 border-dashed rounded-xl flex flex-col items-center justify-center p-8 text-center">
              {isGenerating ? (
                <div className="flex flex-col items-center">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mb-6"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Wand2 size={24} className="text-indigo-400 animate-pulse" />
                    </div>
                  </div>
                  <h3 className="text-xl text-white mb-2">Sculpting Narrative...</h3>
                  <p className="text-slate-400 max-w-xs">Aligning your experience with the unique frequency of {targetJob.company}.</p>
                </div>
              ) : (
                <>
                  <div className="bg-indigo-600/10 p-4 rounded-full mb-6">
                    <Wand2 size={32} className="text-indigo-400" />
                  </div>
                  <h3 className="text-xl text-white mb-2">Ready to Transform?</h3>
                  <p className="text-slate-400 mb-8 max-w-sm">Lummy will rewrite your resume to highlight the skills and experiences most relevant to this specific role.</p>
                  <button 
                    onClick={handleSculpt}
                    className="group relative bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white px-8 py-3 rounded-xl font-medium transition-all shadow-lg shadow-indigo-900/30 hover:shadow-indigo-900/50 flex items-center gap-3 overflow-hidden"
                  >
                    <span className="relative z-10">Generate Tailored CV</span>
                    <ArrowRight className="relative z-10 group-hover:translate-x-1 transition-transform" size={18} />
                    <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 blur-md"></div>
                  </button>
                </>
              )}
            </div>
          ) : (
            <div className="flex-1 flex flex-col min-h-0">
               <div className="bg-indigo-900/20 border border-indigo-500/30 p-4 rounded-xl mb-4 text-sm text-indigo-200 flex gap-3">
                 <div className="mt-1"><CheckCircle size={16} className="text-indigo-400" /></div>
                 <div>
                   <span className="font-semibold block mb-1 text-indigo-300">Architect's Note:</span>
                   {reasoning}
                 </div>
               </div>
               <div className="flex-1 relative">
                 <textarea
                   readOnly
                   value={tailoredResume}
                   className="w-full h-full bg-slate-800 border border-slate-700 rounded-xl p-6 text-emerald-50/90 font-mono text-sm focus:outline-none focus:border-emerald-500 resize-none leading-relaxed"
                 />
                 <button 
                  onClick={handleSculpt}
                  disabled={isGenerating}
                  className="absolute bottom-4 right-4 bg-slate-700 hover:bg-slate-600 text-white p-3 rounded-full shadow-lg transition-colors border border-slate-600"
                  title="Regenerate"
                 >
                   <RefreshCw size={18} className={isGenerating ? 'animate-spin' : ''} />
                 </button>
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResumeArchitect;

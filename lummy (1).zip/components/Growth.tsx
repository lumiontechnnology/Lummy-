import React, { useState } from 'react';
import { generateGrowthPlan, GrowthPlan, GrowthMilestone } from '../services/geminiService';
import { Target, Flag, BookOpen, Zap, CheckCircle2, Lock, ArrowRight, Trophy, Sparkles, TrendingUp } from 'lucide-react';

const Growth: React.FC = () => {
  const [currentRole, setCurrentRole] = useState('');
  const [targetRole, setTargetRole] = useState('');
  const [plan, setPlan] = useState<GrowthPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [completedHabits, setCompletedHabits] = useState<Set<string>>(new Set());

  const handleGenerate = async () => {
    if (!currentRole || !targetRole) return;
    setLoading(true);
    try {
      const result = await generateGrowthPlan(currentRole, targetRole);
      setPlan(result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const toggleHabit = (habit: string) => {
    const newSet = new Set(completedHabits);
    if (newSet.has(habit)) {
      newSet.delete(habit);
    } else {
      newSet.add(habit);
    }
    setCompletedHabits(newSet);
  };

  if (!plan) {
    return (
      <div className="h-full flex flex-col items-center justify-center animate-fade-in">
        <div className="max-w-md w-full bg-slate-800/50 border border-slate-700/50 rounded-2xl p-8 backdrop-blur-sm shadow-xl">
           <div className="w-16 h-16 bg-gradient-to-tr from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-amber-900/20 mx-auto">
              <Target size={32} className="text-white" />
           </div>
           
           <h2 className="text-2xl text-center text-white font-light mb-2">Define Your North Star</h2>
           <p className="text-center text-slate-400 mb-8 text-sm">Lummy will architect a personalized curriculum to bridge the gap between where you are and where you want to be.</p>

           <div className="space-y-4">
             <div>
               <label className="block text-xs uppercase tracking-wider text-slate-500 font-semibold mb-2">Current Role</label>
               <input 
                 value={currentRole}
                 onChange={(e) => setCurrentRole(e.target.value)}
                 placeholder="e.g. Junior Frontend Dev"
                 className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500 transition-colors"
               />
             </div>
             <div>
               <label className="block text-xs uppercase tracking-wider text-slate-500 font-semibold mb-2">Target Ambition</label>
               <input 
                 value={targetRole}
                 onChange={(e) => setTargetRole(e.target.value)}
                 placeholder="e.g. Senior Full Stack Engineer"
                 className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500 transition-colors"
               />
             </div>
             
             <button 
               onClick={handleGenerate}
               disabled={loading || !currentRole || !targetRole}
               className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white py-3.5 rounded-xl font-medium transition-all shadow-lg shadow-amber-900/20 flex items-center justify-center gap-2 mt-4 disabled:opacity-50 disabled:cursor-not-allowed"
             >
               {loading ? (
                 <>
                   <Sparkles size={18} className="animate-spin" /> Designing Path...
                 </>
               ) : (
                 <>
                   Generate Roadmap <ArrowRight size={18} />
                 </>
               )}
             </button>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col animate-fade-in overflow-hidden">
      <header className="mb-6 flex justify-between items-end shrink-0">
        <div>
          <h1 className="text-3xl font-light text-white mb-1 flex items-center gap-2">
            Trajectory to <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400 font-normal">{plan.targetRole}</span>
          </h1>
          <p className="text-slate-400 flex items-center gap-2 text-sm">
            <TrendingUp size={14} className="text-emerald-400" /> 
            Level 4 Architect &bull; Estimated completion: 12 months
          </p>
        </div>
        <button 
          onClick={() => setPlan(null)} 
          className="text-xs text-slate-500 hover:text-white underline"
        >
          Recalibrate Goal
        </button>
      </header>

      <div className="flex-1 flex gap-6 min-h-0">
        {/* Left: Milestone Timeline */}
        <div className="flex-1 bg-slate-800/30 border border-slate-700/30 rounded-2xl p-6 overflow-y-auto relative">
           <div className="absolute top-8 left-9 bottom-8 w-0.5 bg-slate-700/50"></div>
           
           <div className="space-y-8 relative">
             {plan.milestones.map((milestone, index) => {
               const isLocked = milestone.status === 'locked';
               const isCurrent = milestone.status === 'in-progress';
               
               return (
                 <div key={milestone.id} className={`flex gap-6 relative group ${isLocked ? 'opacity-50 blur-[1px] hover:blur-0 transition-all' : ''}`}>
                   {/* Icon Node */}
                   <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 z-10 border-4 ${
                     isCurrent 
                       ? 'bg-amber-500 border-slate-900 shadow-[0_0_0_4px_rgba(245,158,11,0.2)]' 
                       : milestone.status === 'completed' 
                         ? 'bg-emerald-500 border-slate-900' 
                         : 'bg-slate-700 border-slate-900'
                   }`}>
                     {milestone.status === 'completed' ? <CheckCircle2 size={14} className="text-white" /> : 
                      isLocked ? <Lock size={12} className="text-slate-400" /> :
                      <Flag size={14} className="text-white fill-current" />}
                   </div>

                   {/* Content Card */}
                   <div className={`flex-1 rounded-xl p-5 border transition-all ${
                     isCurrent 
                       ? 'bg-gradient-to-br from-slate-800 to-slate-800/50 border-amber-500/30 shadow-lg shadow-amber-900/10' 
                       : 'bg-slate-800/40 border-slate-700/30'
                   }`}>
                     <div className="flex justify-between items-start mb-2">
                       <h3 className={`font-semibold text-lg ${isCurrent ? 'text-amber-100' : 'text-slate-300'}`}>
                         {milestone.title}
                       </h3>
                       <span className="text-xs bg-slate-900/50 px-2 py-1 rounded text-slate-400 border border-slate-700/50">
                         {milestone.duration}
                       </span>
                     </div>
                     
                     <p className="text-slate-400 text-sm mb-4 leading-relaxed">{milestone.description}</p>

                     {/* Skills Tags */}
                     <div className="flex flex-wrap gap-2 mb-4">
                       {milestone.skills.map(skill => (
                         <span key={skill} className={`text-xs px-2 py-1 rounded border ${
                           isCurrent ? 'bg-amber-500/10 border-amber-500/20 text-amber-300' : 'bg-slate-700/30 border-slate-600/30 text-slate-500'
                         }`}>
                           {skill}
                         </span>
                       ))}
                     </div>

                     {/* Resources */}
                     {!isLocked && (
                       <div className="bg-slate-900/50 rounded-lg p-3 space-y-2">
                         <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
                           <BookOpen size={12} /> Recommended Resources
                         </div>
                         <ul className="space-y-1">
                           {milestone.resources.map((res, i) => (
                             <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                               <span className="mt-1.5 w-1 h-1 rounded-full bg-indigo-400 shrink-0"></span>
                               <span className="hover:text-indigo-300 cursor-pointer transition-colors">{res}</span>
                             </li>
                           ))}
                         </ul>
                       </div>
                     )}
                   </div>
                 </div>
               );
             })}
             
             {/* Final Goal Node */}
             <div className="flex gap-6 relative opacity-50">
                <div className="w-8 h-8 rounded-full bg-slate-800 border-4 border-slate-900 flex items-center justify-center shrink-0 z-10 text-slate-600">
                   <Trophy size={14} />
                </div>
                <div className="py-1">
                   <span className="text-slate-500 font-medium">Goal Achieved: {plan.targetRole}</span>
                </div>
             </div>
           </div>
        </div>

        {/* Right: Daily Habits & Stats */}
        <div className="w-80 flex flex-col gap-6">
           {/* Daily Habits */}
           <div className="bg-gradient-to-br from-indigo-900/40 to-violet-900/40 border border-indigo-500/20 rounded-2xl p-6">
             <div className="flex items-center gap-2 text-indigo-300 font-semibold mb-4">
               <Zap size={18} /> Daily Rituals
             </div>
             <p className="text-xs text-indigo-200/60 mb-4">Recurring tasks to accelerate your growth velocity.</p>
             
             <div className="space-y-3">
               {plan.habits.map((habit, i) => {
                 const isDone = completedHabits.has(habit);
                 return (
                   <div 
                    key={i}
                    onClick={() => toggleHabit(habit)}
                    className={`flex items-start gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                      isDone ? 'bg-emerald-500/20 text-emerald-100' : 'bg-slate-800/50 text-slate-300 hover:bg-slate-800'
                    }`}
                   >
                     <div className={`mt-0.5 w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                       isDone ? 'bg-emerald-500 border-emerald-500' : 'border-slate-500'
                     }`}>
                       {isDone && <CheckCircle2 size={12} className="text-white" />}
                     </div>
                     <span className={`text-sm ${isDone ? 'line-through opacity-70' : ''}`}>{habit}</span>
                   </div>
                 );
               })}
             </div>
           </div>

           {/* Stats/Badges */}
           <div className="bg-slate-800/30 border border-slate-700/30 rounded-2xl p-6 flex-1">
              <h3 className="text-slate-300 font-medium mb-4">Skill Inventory</h3>
              <div className="flex flex-wrap gap-1.5">
                {['React', 'TypeScript', 'Node.js', 'System Design', 'Leadership', 'Communication'].map(tag => (
                  <span key={tag} className="text-xs bg-slate-900 text-slate-400 px-2 py-1 rounded border border-slate-800">
                    {tag}
                  </span>
                ))}
                <span className="text-xs text-slate-600 px-1 py-1">+4 more</span>
              </div>
              
              <div className="mt-8">
                <div className="flex justify-between text-xs text-slate-400 mb-2">
                  <span>Current Progress</span>
                  <span>15%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                   <div className="h-full w-[15%] bg-gradient-to-r from-amber-500 to-orange-500 rounded-full"></div>
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Growth;
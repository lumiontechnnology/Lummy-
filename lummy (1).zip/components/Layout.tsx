import React, { useState, useEffect, useRef } from 'react';
import { AppView, UserRole, AppNotification } from '../types';
import { dataService } from '../services/dataService';
import { 
  LayoutDashboard, Telescope, PenTool, Mic2, Hexagon, LogOut, 
  Briefcase, Users, MessageSquare, Calendar, PlusCircle, Globe, Settings,
  Bell, Mail, Check, Inbox
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeView: AppView;
  userRole: UserRole;
  onNavigate: (view: AppView) => void;
  onToggleRole: () => void;
}

// Custom Lummy "Spark" Logo
const LummyLogo = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" className={className}>
    <path d="M12 0L14.8 8.6L24 12L14.8 15.4L12 24L9.2 15.4L0 12L9.2 8.6L12 0Z" />
  </svg>
);

const NavItem: React.FC<{ 
  icon: React.ElementType, 
  label: string, 
  active: boolean, 
  onClick: () => void 
}> = ({ icon: Icon, label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group active:scale-95 ${
      active 
        ? 'bg-gradient-to-r from-indigo-600/90 to-violet-600/90 text-white shadow-lg shadow-indigo-900/20' 
        : 'text-slate-400 hover:text-white hover:bg-slate-800'
    }`}
  >
    <Icon size={20} className={active ? 'text-white' : 'text-slate-500 group-hover:text-white'} />
    <span className="font-medium tracking-wide">{label}</span>
  </button>
);

const Layout: React.FC<LayoutProps> = ({ children, activeView, userRole, onNavigate, onToggleRole }) => {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const isCandidate = userRole === 'CANDIDATE';
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Poll for notifications periodically
    const fetchNotifications = async () => {
      const data = await dataService.getNotifications(userRole);
      setNotifications(data);
    };

    fetchNotifications();
    const interval = setInterval(fetchNotifications, 5000);
    return () => clearInterval(interval);
  }, [userRole, activeView]); // Re-fetch when view changes to capture interactions

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAllRead = async () => {
    await dataService.markAllNotificationsRead(userRole);
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-950">
      {/* Sidebar */}
      <aside className="w-64 flex flex-col border-r border-slate-800 bg-slate-900/50 backdrop-blur-xl p-4 z-20">
        <div className="flex items-center gap-3 px-4 py-6 mb-6">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20 transition-all duration-500 ${isCandidate ? 'bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-600' : 'bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-600'}`}>
            <LummyLogo className="text-white w-7 h-7 drop-shadow-md" />
          </div>
          <div>
             <span className="text-2xl font-light tracking-wide text-white block leading-none">Lummy</span>
             <span className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold">{isCandidate ? 'Architect' : 'Visionary'}</span>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          {isCandidate ? (
            <>
              <NavItem icon={LayoutDashboard} label="Orchestrate" active={activeView === AppView.DASHBOARD} onClick={() => onNavigate(AppView.DASHBOARD)} />
              <NavItem icon={Telescope} label="Scout" active={activeView === AppView.SCOUT} onClick={() => onNavigate(AppView.SCOUT)} />
              <NavItem icon={PenTool} label="Sculpt" active={activeView === AppView.ARCHITECT} onClick={() => onNavigate(AppView.ARCHITECT)} />
              <NavItem icon={Mic2} label="Rehearse" active={activeView === AppView.REHEARSE} onClick={() => onNavigate(AppView.REHEARSE)} />
              <NavItem icon={Hexagon} label="Grow" active={activeView === AppView.GROWTH} onClick={() => onNavigate(AppView.GROWTH)} />
              <NavItem icon={Globe} label="Network" active={activeView === AppView.NETWORK} onClick={() => onNavigate(AppView.NETWORK)} />
              <NavItem icon={MessageSquare} label="Messages" active={activeView === AppView.MESSAGES} onClick={() => onNavigate(AppView.MESSAGES)} />
            </>
          ) : (
            <>
              <NavItem icon={LayoutDashboard} label="Dashboard" active={activeView === AppView.EMPLOYER_DASHBOARD} onClick={() => onNavigate(AppView.EMPLOYER_DASHBOARD)} />
              <NavItem icon={Users} label="Talent Hunter" active={activeView === AppView.TALENT_SEARCH} onClick={() => onNavigate(AppView.TALENT_SEARCH)} />
              <NavItem icon={PlusCircle} label="Post Job" active={activeView === AppView.POST_JOB} onClick={() => onNavigate(AppView.POST_JOB)} />
              <NavItem icon={Calendar} label="Schedule" active={activeView === AppView.SCHEDULE} onClick={() => onNavigate(AppView.SCHEDULE)} />
              <NavItem icon={MessageSquare} label="Messages" active={activeView === AppView.MESSAGES} onClick={() => onNavigate(AppView.MESSAGES)} />
            </>
          )}
        </nav>

        <div className="pt-6 border-t border-slate-800 space-y-4">
           {/* Role Switcher */}
           <button 
             onClick={onToggleRole}
             className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs py-2 px-3 rounded-lg transition-colors border border-slate-700 flex justify-center uppercase tracking-wider active:scale-95"
           >
             Switch to {isCandidate ? 'Employer' : 'Candidate'}
           </button>

           <div className="flex gap-2">
             <div 
               className="flex-1 flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-slate-800/80 cursor-pointer transition-colors group"
               onClick={() => console.log('Open profile settings')}
             >
                <div className="w-8 h-8 rounded-full bg-slate-700 border border-slate-600 overflow-hidden relative group-hover:border-indigo-500/50 transition-colors">
                  <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-400 group-hover:text-white">
                      {isCandidate ? 'AC' : 'HR'}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-white font-medium truncate group-hover:text-indigo-300 transition-colors">{isCandidate ? 'Alex Chen' : 'Sarah Miller'}</div>
                  <div className="text-xs text-slate-500 truncate">{isCandidate ? 'Pro Member' : 'Recruitment Lead'}</div>
                </div>
             </div>
             
             {/* Notification Bell */}
             <div className="relative" ref={notificationRef}>
               <button 
                 onClick={() => setShowNotifications(!showNotifications)}
                 className={`w-12 h-full flex items-center justify-center rounded-xl transition-colors relative ${showNotifications ? 'bg-slate-800 text-white' : 'hover:bg-slate-800 text-slate-400'}`}
               >
                 <Bell size={18} />
                 {unreadCount > 0 && (
                   <span className="absolute top-2 right-3 w-2.5 h-2.5 bg-red-500 rounded-full border border-slate-900"></span>
                 )}
               </button>

               {/* Notifications Popover */}
               {showNotifications && (
                 <div className="absolute bottom-full left-0 mb-4 w-[320px] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden animate-fade-in z-50">
                    <div className="p-3 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
                       <h3 className="text-sm font-semibold text-white pl-2">Notifications</h3>
                       {unreadCount > 0 && (
                         <button onClick={handleMarkAllRead} className="text-xs text-indigo-400 hover:text-indigo-300 px-2 py-1 rounded hover:bg-indigo-500/10">Mark all read</button>
                       )}
                    </div>
                    <div className="max-h-[300px] overflow-y-auto">
                       {notifications.length === 0 ? (
                         <div className="p-8 text-center text-slate-500 flex flex-col items-center">
                            <Inbox size={24} className="mb-2 opacity-50" />
                            <p className="text-xs">No notifications yet</p>
                         </div>
                       ) : (
                         notifications.map(notif => (
                           <div key={notif.id} className={`p-4 border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors ${!notif.read ? 'bg-indigo-500/5' : ''}`}>
                             <div className="flex gap-3">
                               <div className={`mt-1 w-2 h-2 rounded-full shrink-0 ${!notif.read ? 'bg-indigo-500' : 'bg-transparent'}`}></div>
                               <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    {notif.type === 'email' && <Mail size={12} className="text-slate-400" />}
                                    <span className="text-xs font-semibold text-slate-200">{notif.title}</span>
                                  </div>
                                  <p className="text-xs text-slate-400 leading-relaxed mb-1">{notif.message}</p>
                                  <span className="text-[10px] text-slate-600">{new Date(notif.timestamp).toLocaleTimeString()}</span>
                               </div>
                             </div>
                           </div>
                         ))
                       )}
                    </div>
                 </div>
               )}
             </div>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-slate-950 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950 pointer-events-none z-0"></div>
        <div className="relative z-10 p-8 h-full">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
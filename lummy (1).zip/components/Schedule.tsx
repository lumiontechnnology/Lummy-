import React, { useState, useEffect } from 'react';
import { CalendarEvent } from '../types';
import { Calendar as CalendarIcon, Video, Clock, MapPin, ExternalLink } from 'lucide-react';
import { dataService } from '../services/dataService';

const Schedule: React.FC = () => {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvents = async () => {
      const data = await dataService.getEvents();
      setEvents(data);
      setLoading(false);
    };
    fetchEvents();
  }, []);

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-8 animate-fade-in">
       {/* Left: Agenda */}
       <div className="w-1/3 flex flex-col">
          <h2 className="text-2xl font-light text-white mb-6">Upcoming Interviews</h2>
          <div className="space-y-4 overflow-y-auto pr-2">
             {loading ? (
                <div className="text-slate-500 text-sm">Loading schedule...</div>
             ) : events.map(evt => (
               <div 
                 key={evt.id} 
                 className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-5 hover:border-indigo-500/50 hover:bg-slate-800/60 hover:-translate-y-1 transition-all duration-200 cursor-pointer group shadow-sm hover:shadow-indigo-900/10"
                 onClick={() => console.log('Open event details')}
               >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold text-white group-hover:text-indigo-300 transition-colors">{evt.title}</h3>
                      <p className="text-indigo-300 text-sm group-hover:text-indigo-200">w/ {evt.candidate}</p>
                    </div>
                    <div className="bg-slate-700/50 p-2 rounded-lg group-hover:bg-slate-700 transition-colors">
                       <CalendarIcon size={16} className="text-slate-400 group-hover:text-white" />
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm text-slate-400">
                     <div className="flex items-center gap-2">
                        <Clock size={14} /> {evt.date} @ {evt.time}
                     </div>
                     <div className="flex items-center gap-2">
                        {evt.type === 'Google Meet' ? <Video size={14} className="text-emerald-400" /> : <MapPin size={14} className="text-amber-400" />} 
                        <span className={evt.type === 'Google Meet' ? 'text-emerald-400/80 group-hover:text-emerald-400' : 'text-slate-400 group-hover:text-amber-300'}>{evt.type}</span>
                     </div>
                  </div>

                  {evt.link && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        window.open(`https://${evt.link}`, '_blank');
                      }}
                      className="w-full mt-4 bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 border border-emerald-600/20 py-2 rounded-lg text-sm transition-colors flex items-center justify-center gap-2 active:scale-95"
                    >
                       <Video size={16} /> Join Google Meet
                    </button>
                  )}
               </div>
             ))}
          </div>
       </div>

       {/* Right: Calendar Visual (Mock) */}
       <div className="flex-1 bg-slate-800/30 border border-slate-700/30 rounded-2xl p-6 flex flex-col">
          <header className="flex justify-between items-center mb-6">
             <h3 className="text-white font-medium">October 2023</h3>
             <div className="flex gap-2">
               <button className="px-3 py-1 text-sm bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors rounded">Week</button>
               <button className="px-3 py-1 text-sm bg-indigo-600 hover:bg-indigo-500 text-white transition-colors rounded">Month</button>
             </div>
          </header>
          
          <div className="flex-1 grid grid-cols-7 gap-px bg-slate-700 border border-slate-700 rounded-lg overflow-hidden">
             {/* Days Header */}
             {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
               <div key={day} className="bg-slate-800 p-2 text-center text-xs text-slate-500 uppercase tracking-wider">{day}</div>
             ))}
             {/* Calendar Grid (Simplified) */}
             {Array.from({ length: 35 }).map((_, i) => {
                const day = i - 2; // Offset for start date
                const isToday = day === 24;
                const isCurrentMonth = day > 0 && day <= 31;
                
                return (
                  <div 
                    key={i} 
                    className={`bg-slate-900/80 p-2 min-h-[80px] transition-colors relative ${!isCurrentMonth ? 'opacity-30' : 'hover:bg-slate-800 cursor-pointer'}`}
                    onClick={() => isCurrentMonth && console.log(`Clicked day ${day}`)}
                  >
                    <span className={`text-sm ${isToday ? 'bg-indigo-600 text-white w-6 h-6 rounded-full flex items-center justify-center' : 'text-slate-400'}`}>
                      {isCurrentMonth ? day : ''}
                    </span>
                    {day === 24 && (
                      <div className="mt-1 text-[10px] bg-emerald-500/20 text-emerald-400 px-1 py-0.5 rounded truncate border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors">
                        10a Tech Int...
                      </div>
                    )}
                    {day === 24 && (
                      <div className="mt-1 text-[10px] bg-emerald-500/20 text-emerald-400 px-1 py-0.5 rounded truncate border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors">
                        2p Culture...
                      </div>
                    )}
                    {day === 25 && (
                      <div className="mt-1 text-[10px] bg-amber-500/20 text-amber-400 px-1 py-0.5 rounded truncate border border-amber-500/30 hover:bg-amber-500/30 transition-colors">
                        11a Final...
                      </div>
                    )}
                  </div>
                );
             })}
          </div>
       </div>
    </div>
  );
};

export default Schedule;
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Briefcase, TrendingUp, Calendar, Zap, ChevronRight } from 'lucide-react';

const data = [
  { name: 'Week 1', apps: 2, interviews: 0 },
  { name: 'Week 2', apps: 5, interviews: 1 },
  { name: 'Week 3', apps: 8, interviews: 2 },
  { name: 'Week 4', apps: 12, interviews: 4 },
  { name: 'Week 5', apps: 15, interviews: 6 },
];

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header className="mb-8">
        <h1 className="text-3xl font-light text-white mb-2">Welcome back, Architect.</h1>
        <p className="text-slate-400 font-light">Your career symphony is progressing beautifully. Here is today's composition.</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-indigo-500/30 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to applications')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-indigo-300 transition-colors">Applications Sent</span>
            <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400 group-hover:bg-indigo-500/20 transition-colors">
              <Briefcase size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">42</div>
          <div className="text-xs text-green-400 mt-2 flex items-center gap-1">
            <TrendingUp size={12} /> +12% this week
          </div>
        </div>

        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-emerald-500/30 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to stats')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-emerald-300 transition-colors">Interview Rate</span>
            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
              <Zap size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">18%</div>
          <div className="text-xs text-slate-500 mt-2">Market avg: 4%</div>
        </div>

        <div 
          className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 backdrop-blur-sm cursor-pointer hover:bg-slate-800 hover:border-amber-500/30 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => console.log('Navigate to schedule')}
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 text-sm group-hover:text-amber-300 transition-colors">Upcoming</span>
            <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400 group-hover:bg-amber-500/20 transition-colors">
              <Calendar size={20} />
            </div>
          </div>
          <div className="text-3xl font-semibold text-white">3</div>
          <div className="text-xs text-slate-500 mt-2">Interviews scheduled</div>
        </div>

        <div 
          className="bg-gradient-to-br from-indigo-600 to-violet-700 p-6 rounded-2xl shadow-lg shadow-indigo-900/20 cursor-pointer hover:shadow-indigo-900/40 hover:-translate-y-1 transition-all duration-200 group"
          onClick={() => alert("Premium features coming soon!")}
        >
          <div className="flex flex-col h-full justify-between">
            <div>
              <h3 className="text-white font-medium mb-1 flex items-center gap-2">Lummy Premium <ChevronRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -translate-x-2 group-hover:translate-x-0" /></h3>
              <p className="text-indigo-200 text-xs">Unlock deeper insights.</p>
            </div>
            <button className="mt-4 bg-white/10 hover:bg-white/20 text-white text-sm py-2 px-4 rounded-lg transition-colors backdrop-blur-md w-full text-left">
              View Plan
            </button>
          </div>
        </div>
      </div>

      {/* Main Chart */}
      <div className="bg-slate-800/30 p-8 rounded-2xl border border-slate-700/30 hover:border-slate-700/50 transition-colors">
        <h2 className="text-xl font-light text-white mb-6">Trajectory Analysis</h2>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorApps" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#818cf8" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#818cf8" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorInterviews" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#34d399" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#34d399" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                itemStyle={{ color: '#e2e8f0' }}
              />
              <Area type="monotone" dataKey="apps" stroke="#818cf8" strokeWidth={3} fillOpacity={1} fill="url(#colorApps)" />
              <Area type="monotone" dataKey="interviews" stroke="#34d399" strokeWidth={3} fillOpacity={1} fill="url(#colorInterviews)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
import React, { useState, useEffect } from 'react';
import { NetworkProfile, AppView } from '../types';
import { getNetworkSuggestions } from '../services/geminiService';
import { Search, UserPlus, MessageSquare, MapPin, Briefcase, Users, X, UserCheck, Sparkles } from 'lucide-react';

interface NetworkProps {
  onNavigate: (view: AppView) => void;
}

const Network: React.FC<NetworkProps> = ({ onNavigate }) => {
  const [query, setQuery] = useState('');
  const [profiles, setProfiles] = useState<NetworkProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<NetworkProfile | null>(null);

  // Load initial recommendations
  useEffect(() => {
    handleSearch('');
  }, []);

  const handleSearch = async (searchQuery: string) => {
    setLoading(true);
    const results = await getNetworkSuggestions(searchQuery);
    setProfiles(results);
    setLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch(query);
    }
  };

  const toggleConnection = (id: string) => {
    setProfiles(profiles.map(p => 
      p.id === id ? { ...p, isConnected: !p.isConnected } : p
    ));
    if (selectedProfile && selectedProfile.id === id) {
      setSelectedProfile(prev => prev ? { ...prev, isConnected: !prev.isConnected } : null);
    }
  };

  const handleMessageClick = () => {
    setSelectedProfile(null);
    onNavigate(AppView.MESSAGES);
  };

  return (
    <div className="h-full flex flex-col animate-fade-in relative">
      <header className="mb-6">
        <h1 className="text-3xl font-light text-white mb-2">My Network</h1>
        <p className="text-slate-400">Connect with industry leaders, mentors, and peers to accelerate your career.</p>
      </header>

      {/* Search Bar */}
      <div className="relative mb-8 max-w-2xl">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <Search className="text-slate-500" size={20} />
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Search by role, company, or skill..."
          className="w-full bg-slate-800/50 border border-slate-700 text-white rounded-2xl py-4 pl-12 pr-32 focus:outline-none focus:border-indigo-500 transition-colors shadow-lg"
        />
        <button
          onClick={() => handleSearch(query)}
          className="absolute right-2 top-2 bottom-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 rounded-xl font-medium transition-colors active:scale-95"
        >
          Find
        </button>
      </div>

      {/* Content Grid */}
      <div className="flex-1 overflow-y-auto pr-2">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500 space-y-4">
             <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin"></div>
             <p className="animate-pulse">Discovering professionals...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {profiles.map(profile => (
              <div 
                key={profile.id}
                onClick={() => setSelectedProfile(profile)}
                className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 hover:border-indigo-500/30 hover:bg-slate-800/60 hover:-translate-y-1 transition-all duration-200 cursor-pointer group flex flex-col shadow-sm hover:shadow-indigo-900/20"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xl font-bold text-white shadow-lg">
                    {profile.avatar || profile.name.charAt(0)}
                  </div>
                  {profile.isConnected ? (
                     <span className="bg-emerald-500/10 text-emerald-400 text-xs px-2 py-1 rounded-full border border-emerald-500/20 flex items-center gap-1">
                       <UserCheck size={12} /> Connected
                     </span>
                  ) : (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleConnection(profile.id);
                      }}
                      className="bg-slate-700 hover:bg-indigo-600 text-white p-2 rounded-full transition-colors border border-slate-600 group-hover:border-indigo-500/50 active:scale-95"
                    >
                      <UserPlus size={18} />
                    </button>
                  )}
                </div>

                <div className="mb-4">
                  <h3 className="text-lg font-semibold text-white group-hover:text-indigo-300 transition-colors">{profile.name}</h3>
                  <p className="text-slate-300 text-sm font-medium">{profile.role}</p>
                  <p className="text-slate-500 text-sm">{profile.company}</p>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-400 mb-4">
                  <MapPin size={12} /> {profile.location}
                  <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
                  <Users size={12} /> {profile.mutualConnections} mutual
                </div>

                <div className="mt-auto">
                   <div className="flex flex-wrap gap-2">
                     {profile.skills.slice(0, 3).map(skill => (
                       <span key={skill} className="text-xs bg-slate-900/50 text-slate-400 px-2 py-1 rounded border border-slate-700/50">
                         {skill}
                       </span>
                     ))}
                   </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Profile Modal/Overlay */}
      {selectedProfile && (
        <div className="absolute inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm cursor-pointer" onClick={() => setSelectedProfile(null)}></div>
          <div className="w-full md:w-[480px] bg-slate-900 border-l border-slate-800 shadow-2xl h-full p-8 relative overflow-y-auto animate-fade-in-right">
             <button 
               onClick={() => setSelectedProfile(null)}
               className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors p-2 hover:bg-slate-800 rounded-full"
             >
               <X size={24} />
             </button>

             <div className="flex flex-col items-center mb-8">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-500 to-fuchsia-600 flex items-center justify-center text-3xl font-bold text-white shadow-xl mb-4">
                  {selectedProfile.avatar || selectedProfile.name.charAt(0)}
                </div>
                <h2 className="text-2xl font-semibold text-white text-center">{selectedProfile.name}</h2>
                <p className="text-indigo-400 font-medium text-center">{selectedProfile.role}</p>
                <div className="flex items-center gap-2 text-slate-400 text-sm mt-1">
                   <Briefcase size={14} /> {selectedProfile.company}
                   <span>•</span>
                   <MapPin size={14} /> {selectedProfile.location}
                </div>
             </div>

             <div className="flex justify-center gap-4 mb-8">
               <button 
                 onClick={() => toggleConnection(selectedProfile.id)}
                 className={`flex-1 py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-all active:scale-95 ${
                   selectedProfile.isConnected 
                     ? 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700' 
                     : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-900/20'
                 }`}
               >
                 {selectedProfile.isConnected ? <UserCheck size={18} /> : <UserPlus size={18} />}
                 {selectedProfile.isConnected ? 'Connected' : 'Connect'}
               </button>
               <button 
                 onClick={handleMessageClick}
                 className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2.5 rounded-xl font-medium transition-all active:scale-95 border border-slate-700 flex items-center justify-center gap-2"
               >
                 <MessageSquare size={18} /> Message
               </button>
             </div>

             <div className="space-y-6">
                <div className="bg-slate-800/30 rounded-xl p-5 border border-slate-700/50">
                   <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-3">About</h3>
                   <p className="text-slate-300 leading-relaxed text-sm">
                     {selectedProfile.bio} Passionate about building scalable systems and fostering engineering culture. Always open to discussing new technologies and leadership challenges.
                   </p>
                </div>

                <div>
                   <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-3">Top Skills</h3>
                   <div className="flex flex-wrap gap-2">
                      {selectedProfile.skills.map(skill => (
                        <span key={skill} className="px-3 py-1.5 bg-slate-800 text-indigo-200 rounded-lg text-sm border border-slate-700 cursor-default hover:border-indigo-500/50 transition-colors">
                          {skill}
                        </span>
                      ))}
                   </div>
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-3">Activity</h3>
                  <div className="bg-slate-800/30 rounded-xl p-4 border border-slate-700/50 flex gap-3 cursor-pointer hover:bg-slate-800/50 transition-colors">
                     <div className="mt-1"><Sparkles size={16} className="text-amber-400" /></div>
                     <div>
                        <p className="text-sm text-slate-300 mb-1"><span className="font-semibold text-white">{selectedProfile.name}</span> celebrated a work anniversary.</p>
                        <span className="text-xs text-slate-500">2 days ago</span>
                     </div>
                  </div>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Network;
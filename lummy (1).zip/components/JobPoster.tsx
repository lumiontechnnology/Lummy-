
import React, { useState } from 'react';
import { generateJobDescription } from '../services/geminiService';
import { dataService } from '../services/dataService';
import { Sparkles, ArrowRight, CheckCircle, Mail, AtSign } from 'lucide-react';

const JobPoster: React.FC = () => {
  const [title, setTitle] = useState('');
  const [keywords, setKeywords] = useState('');
  const [description, setDescription] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleGenerate = async () => {
    if (!title || !keywords) return;
    setIsGenerating(true);
    const result = await generateJobDescription(title, keywords);
    setDescription(result);
    setIsGenerating(false);
  };

  const validateEmail = (email: string) => {
    // Robust email regex
    return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setContactEmail(val);
    if (val && !validateEmail(val)) {
        setEmailError('Invalid email format');
    } else {
        setEmailError('');
    }
  };

  const handlePublish = async () => {
    if (!title || !description || !contactEmail || emailError) return;
    setIsPublishing(true);
    
    // Save to backend
    await dataService.createJob({
      title,
      company: 'Acme Corp', // Default for employer view
      location: 'Remote', // Default
      salary: '$Competitive', // Default
      description,
      requirements: keywords.split(',').map(k => k.trim()),
      applyLink: '#',
    });

    // Simulate sending email to candidates (handled inside createJob dataService, but we show UI feedback here)
    await new Promise(resolve => setTimeout(resolve, 800)); // Delay for effect

    setIsPublishing(false);
    setShowSuccess(true);
    
    // Reset after delay
    setTimeout(() => {
      setShowSuccess(false);
      setTitle('');
      setKeywords('');
      setDescription('');
      setContactEmail('');
    }, 4000);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
       <header className="mb-8">
          <h1 className="text-3xl font-light text-white mb-2">Create New Position</h1>
          <p className="text-slate-400">Let AI craft the perfect invitation for your next team member.</p>
        </header>

        {showSuccess ? (
          <div className="bg-emerald-500/10 border border-emerald-500/50 rounded-2xl p-12 text-center animate-fade-in">
            <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-emerald-500/30">
               <CheckCircle size={40} className="text-white" />
            </div>
            <h2 className="text-2xl text-white font-medium mb-2">Job Posted Successfully!</h2>
            <p className="text-slate-400 mb-4">Your listing is now live and visible to candidates.</p>
            <div className="inline-flex items-center gap-2 bg-slate-900/50 px-4 py-2 rounded-lg border border-slate-700/50 text-indigo-300 text-sm">
               <Mail size={14} />
               <span>Job Alert emails sent to matching candidates</span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-8 backdrop-blur-sm shadow-xl">
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div>
                  <label className="block text-slate-400 text-sm font-medium mb-2">Job Title</label>
                  <input 
                    type="text" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Senior Product Designer"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-colors"
                  />
              </div>
              <div>
                  <label className="block text-slate-400 text-sm font-medium mb-2">Key Skills/Requirements</label>
                  <input 
                    type="text" 
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    placeholder="e.g. Figma, Prototyping, Leadership"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-colors"
                  />
              </div>
            </div>

            <div className="mb-6">
                <label className="block text-slate-400 text-sm font-medium mb-2">Contact Email for Applicants</label>
                <div className="relative">
                  <span className="absolute left-4 top-3.5 text-slate-500"><AtSign size={18} /></span>
                  <input 
                    type="email" 
                    value={contactEmail}
                    onChange={handleEmailChange}
                    placeholder="careers@company.com"
                    className={`w-full bg-slate-900 border rounded-xl pl-12 pr-4 py-3 text-white focus:outline-none transition-colors ${emailError ? 'border-red-500 focus:border-red-500' : 'border-slate-700 focus:border-indigo-500'}`}
                  />
                </div>
                {emailError && <p className="text-xs text-red-400 mt-1 ml-1">{emailError}</p>}
            </div>

            <div className="mb-6 relative">
              <div className="flex justify-between items-center mb-2">
                  <label className="block text-slate-400 text-sm font-medium">Job Description</label>
                  <button 
                    onClick={handleGenerate}
                    disabled={isGenerating || !title}
                    className="text-xs flex items-center gap-1 text-indigo-400 hover:text-indigo-300 disabled:opacity-50"
                  >
                    <Sparkles size={12} /> {isGenerating ? 'Writing...' : 'Auto-Generate with AI'}
                  </button>
              </div>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full h-64 bg-slate-900 border border-slate-700 rounded-xl px-4 py-4 text-slate-300 focus:outline-none focus:border-indigo-500 transition-colors resize-none leading-relaxed font-mono text-sm"
                placeholder="Description will appear here..."
              />
            </div>

            <div className="flex justify-end gap-4">
                <button className="px-6 py-2 text-slate-400 hover:text-white transition-colors">Save Draft</button>
                <button 
                  onClick={handlePublish}
                  disabled={isPublishing || !title || !description || !contactEmail || !!emailError}
                  className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-medium transition-colors shadow-lg shadow-emerald-900/20 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isPublishing ? 'Publishing...' : 'Publish Position'} <ArrowRight size={18} />
                </button>
            </div>
          </div>
        )}
    </div>
  );
};

export default JobPoster;

import React, { useState, useEffect, useRef } from 'react';
import { Job, Message } from '../types';
import { createInterviewSession, sendInterviewMessage, generateInterviewFeedback, InterviewFeedback } from '../services/geminiService';
import { Chat } from '@google/genai';
import { Mic, Send, User, Bot, StopCircle, PlayCircle, Award, TrendingUp, AlertCircle, RotateCcw, Loader2 } from 'lucide-react';

interface InterviewSimProps {
  targetJob: Job | null;
}

const InterviewSim: React.FC<InterviewSimProps> = ({ targetJob }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const [isSessionActive, setIsSessionActive] = useState(false);
  
  // Feedback States
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [feedback, setFeedback] = useState<InterviewFeedback | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startSession = () => {
    if (!targetJob) return;
    setMessages([]);
    setFeedback(null);
    setIsLoading(true);
    const session = createInterviewSession(targetJob.title, targetJob.company);
    setChatSession(session);
    setIsSessionActive(true);

    // Initial greeting from AI
    sendInterviewMessage(session, "Hello, I'm ready for the interview.")
      .then(response => {
        setMessages([{
          id: Date.now().toString(),
          role: 'model',
          senderId: 'ai',
          senderName: 'Lummy (Interviewer)',
          content: response,
          timestamp: Date.now()
        }]);
      })
      .finally(() => setIsLoading(false));
  };

  const endSession = async () => {
    if (messages.length < 2) {
      setIsSessionActive(false);
      return;
    }

    setIsSessionActive(false);
    setIsGeneratingFeedback(true);
    
    try {
      const result = await generateInterviewFeedback(messages);
      setFeedback(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingFeedback(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || !chatSession) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      senderId: 'user',
      senderName: 'Me',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await sendInterviewMessage(chatSession, userMsg.content);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        senderId: 'ai',
        senderName: 'Lummy (Interviewer)',
        content: responseText,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      console.error("Chat error", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!targetJob) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-500">
        <Bot size={48} className="mb-4 opacity-50" />
        <h2 className="text-xl text-slate-300 mb-2">No Interview Scheduled</h2>
        <p>Select a job from the Scout tab to begin a rehearsal.</p>
      </div>
    );
  }

  // Feedback Report View
  if (isGeneratingFeedback) {
    return (
       <div className="h-full flex flex-col items-center justify-center animate-fade-in">
          <div className="relative mb-6">
             <div className="w-20 h-20 rounded-full border-4 border-indigo-500/30 border-t-indigo-500 animate-spin"></div>
             <div className="absolute inset-0 flex items-center justify-center">
               <Award size={32} className="text-indigo-400 opacity-50" />
             </div>
          </div>
          <h2 className="text-2xl text-white font-light mb-2">Analyzing Performance</h2>
          <p className="text-slate-400">Reviewing your answers against {targetJob.company}'s standards...</p>
       </div>
    );
  }

  if (feedback) {
    return (
      <div className="h-full flex flex-col animate-fade-in max-w-5xl mx-auto overflow-y-auto pr-2">
        <header className="mb-8 flex justify-between items-center">
           <div>
             <h1 className="text-3xl font-light text-white mb-2">Interview Report Card</h1>
             <p className="text-slate-400">Analysis for <span className="text-indigo-400">{targetJob.title}</span> role</p>
           </div>
           <button 
             onClick={startSession}
             className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors border border-slate-600"
           >
             <RotateCcw size={16} /> New Session
           </button>
        </header>

        <div className="grid grid-cols-3 gap-6 mb-8">
           {/* Score Card */}
           <div className="col-span-1 bg-slate-800/50 border border-slate-700 rounded-2xl p-6 flex flex-col items-center justify-center relative overflow-hidden">
             <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></div>
             <div className="text-sm text-slate-400 uppercase tracking-wider font-semibold mb-4">Overall Score</div>
             <div className={`text-6xl font-bold mb-2 ${feedback.score >= 80 ? 'text-emerald-400' : feedback.score >= 60 ? 'text-amber-400' : 'text-red-400'}`}>
                {feedback.score}
             </div>
             <div className="text-slate-500 text-sm">out of 100</div>
           </div>

           {/* Summary */}
           <div className="col-span-2 bg-slate-800/50 border border-slate-700 rounded-2xl p-6 flex flex-col justify-center">
              <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                <Bot size={18} className="text-indigo-400" /> Executive Summary
              </h3>
              <p className="text-slate-300 leading-relaxed italic">"{feedback.summary}"</p>
           </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
           {/* Strengths */}
           <div className="bg-slate-800/30 border border-emerald-500/20 rounded-2xl p-6">
              <h3 className="text-emerald-400 font-semibold mb-4 flex items-center gap-2">
                <TrendingUp size={18} /> Key Strengths
              </h3>
              <ul className="space-y-3">
                {feedback.strengths.map((item, i) => (
                  <li key={i} className="flex gap-3 text-slate-300 text-sm leading-relaxed">
                    <span className="mt-1 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                    {item}
                  </li>
                ))}
              </ul>
           </div>

           {/* Improvements */}
           <div className="bg-slate-800/30 border border-amber-500/20 rounded-2xl p-6">
              <h3 className="text-amber-400 font-semibold mb-4 flex items-center gap-2">
                <AlertCircle size={18} /> Areas for Growth
              </h3>
               <ul className="space-y-3">
                {feedback.improvements.map((item, i) => (
                  <li key={i} className="flex gap-3 text-slate-300 text-sm leading-relaxed">
                    <span className="mt-1 w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
                    {item}
                  </li>
                ))}
              </ul>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col animate-fade-in max-w-4xl mx-auto">
      <header className="mb-4 flex items-center justify-between border-b border-slate-700/50 pb-4">
        <div>
          <h1 className="text-2xl font-light text-white flex items-center gap-2">
            Interview Rehearsal
            <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-xs border border-indigo-500/30">Live</span>
          </h1>
          <p className="text-slate-400 text-sm">Role: {targetJob.title} @ {targetJob.company}</p>
        </div>
        {!isSessionActive ? (
           <button 
             onClick={startSession}
             className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2 rounded-lg transition-colors flex items-center gap-2 text-sm font-medium shadow-lg shadow-emerald-900/20"
           >
             <PlayCircle size={18} /> Begin Session
           </button>
        ) : (
          <button 
            onClick={endSession}
            className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 px-4 py-2 rounded-lg transition-colors flex items-center gap-2 text-sm"
          >
            <StopCircle size={18} /> End Session
          </button>
        )}
      </header>

      {!isSessionActive && messages.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-slate-800/30 rounded-2xl border border-slate-700/30">
          <div className="w-20 h-20 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-full flex items-center justify-center mb-6 shadow-xl shadow-indigo-900/40">
             <Mic size={32} className="text-white" />
          </div>
          <h2 className="text-2xl text-white font-light mb-3">Prepare to Speak</h2>
          <p className="text-slate-400 max-w-md leading-relaxed">
            Lummy will simulate a hiring manager from <strong>{targetJob.company}</strong>. 
            The session will test your technical knowledge and behavioral responses.
            Treat this as the real thing.
          </p>
        </div>
      ) : (
        <>
          <div className="flex-1 overflow-y-auto space-y-6 pr-4 mb-4">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  msg.role === 'user' ? 'bg-slate-700' : 'bg-indigo-600'
                }`}>
                  {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
                </div>
                <div className={`max-w-[75%] p-4 rounded-2xl leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-slate-700/50 text-slate-100 rounded-tr-none' 
                    : 'bg-indigo-900/30 text-indigo-50 border border-indigo-500/20 rounded-tl-none'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4">
                 <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center flex-shrink-0">
                  <Bot size={20} />
                </div>
                <div className="bg-indigo-900/30 px-6 py-4 rounded-2xl rounded-tl-none border border-indigo-500/20 flex items-center gap-1">
                  <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-100"></span>
                  <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-200"></span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={!isSessionActive || isLoading}
              placeholder={isSessionActive ? "Type your answer..." : "Start the session to begin."}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl py-4 pl-4 pr-14 text-white focus:outline-none focus:border-indigo-500 transition-colors resize-none disabled:opacity-50 disabled:cursor-not-allowed"
              rows={2}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || !isSessionActive || isLoading}
              className="absolute right-3 top-3 p-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white rounded-lg transition-colors"
            >
              <Send size={18} />
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default InterviewSim;